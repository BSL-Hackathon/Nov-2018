'use strict';

	var app = angular.module("app");


	
	
	app.service("servicesAcciones", function($http){
		return {
            getActivos: function(json){
				return $http({ 
					url: 'http://172.20.10.12:3000/api/Activo',
					method: 'GET',
					headers: {'Content-Type':'application/json'} 
				});
            },
            updateActivo: function(json,id){
				return $http({ 
					url: 'http://172.20.10.12:3000/api/Activo/'+id,
					method: 'PUT',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			aprobar: function(json){
				return $http({ 
					url: 'http://172.20.10.12:3000/api/TrxActualiza',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},

			
			
		}
	});