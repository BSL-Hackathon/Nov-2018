'use strict';
var app = angular.module("app");
/*******************************************************************************
 * Controlador Proveedores - Compradores
 */
app.controller("dashboard_ctrl", function($scope, $rootScope, servicesAcciones) {
    
    $scope.acciones = [];

    
   
    servicesAcciones.getActivos().then(function(response){
      alert(response);
      alert(JSON.stringify(response));
      if(response.status == "200"){
        var listaActivos = response.data;
        listaActivos.forEach(function(element) {
          if(element.estado == "PENDIENTE"){
            $scope.acciones.push(element);
          }
          
        });
        
      }
    });
    

    // $scope.acciones.push(accion);
    // $scope.acciones.push(accion2);

    
    var ws = new WebSocket("ws://172.20.10.12:3000");
                   
                  ws.onopen = function() {
                     
                     // Web Socket is connected, send data using send()
                     ws.send("Message to send");
                     alert("Message is sent...");
                  };
                   
                  ws.onmessage = function (evt) { 
                     var received_msg = evt.data;
                     alert("Message is received...");
                     console.log(received_msg);
                  };
                   
                //   ws.onclose = function() { 
                     
                //      // websocket is closed.
                //      alert("Connection is closed..."); 
                //   };


    $scope.aprobar = function(accion){
      accion.okDCV = true;
      let id = accion.activoId;
      accion.okDCV = undefined;
      servicesAcciones.updateActivo(accion,id).then(function(response){

      });
      
      {
  "$class": "com.reload.dcv.Activo",
  "activoId": "1",
  "comprador": "resource:com.reload.dcv.Participante#2",
  "vendedor": "resource:com.reload.dcv.Participante#1",
  "cantAcc": 2,
  "estado": "PENDIENTE",
  "comentario": "",
  "monto": 230,
  "okDCV": false
}
    
      servicesAcciones.aprobar(accion).then(function(response){
        console.log(response);
        if(response.status == 200 && response.statusText == "OK"){
          alert("OK");
        }else{
          alert("NO OK");
        }
      });
      //{ "$class": "com.reload.dcv.Activo", "activoId": "8406", "comprador": "resource:com.reload.dcv.Participante#2", "vendedor": "resource:com.reload.dcv.Participante#1", "cantAcc": 2, "estado": "PENDIENTE", "comentario": "Quis id cupidatat.", "monto": 130.662 }
    }
});
