var app = angular.module("app", [ 'ngRoute','ngSanitize']);

app
        .config([
                '$routeProvider',
                '$httpProvider',
                function($routeProvider, $httpProvider) {

                    $routeProvider
                            .when(
                                '/dashboard',
                                {
                                    templateUrl : 'dashboard.html',
                                    controller : 'dashboard_ctrl'
                                });
                    
                } ]);