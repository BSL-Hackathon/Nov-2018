'use strict';
	var app = angular.module("appPortal");
	/*******************************************************************************
	 * Controlador Noticias - Comprador
	 */
	app.controller("noticiasC_Ctrl", function($scope, $rootScope, $window, $location, 
			servicesPortal) {
			
		var listaNoticias = [];
		var now = moment(new Date());
		var json = {};
		var listaObtener = "";
		$scope.proMod = "";
		$scope.idcliente = 0;
		$scope.idusuario = 0;

		$scope.cargando = false;
		$scope.currentPage = 0;
		$scope.pageSize = 10;
		listaObtener = "noticias";

		json.currentPage = $scope.currentPage;
		json.pageSize = $scope.pageSize;
		json.listaObtener = listaObtener;
		json.action = "getListaNoticias";
		json.filtros = {};
		
		var date = new Date();
		
		$rootScope.$on('refrescar', function(event, args) {
			$scope.cargarDatos(json);
		});
		
		$scope.cargarDatos = function() {
			
			if (listaNoticias != undefined && listaNoticias.length > 0) {
				limpiarListas();
			}
		
			servicesPortal.getListaNoticias(json).then(function(response) {
				angular.forEach(response.data.t,function(item) {
					
					/*if (item.activo == 1) {
						item.activo = "Activo";
						item.btnclass = "btn-success";
						item.accion = "#proveedor-desactivar";
					} else {
						item.activo = "Inactivo";
						item.btnclass = "btn-default";
						item.accion = "#proveedor-activar";
					}*/
						
				});
				
				if (json.filtrado) {
					$scope.total = response.data.rowsReturned == 0 ? 1
							: response.data.rowsReturned;
				} else {
					$scope.total = response.data.totalRows;
				}
		
				$scope.rows = response.data.totalRows;
				listaNoticias = response.data.t;
		
				json.filtrado = false;
				$scope.listaNoticias = listaNoticias;
				json.offSet = undefined;
				
				setTimeout(function() {
					console.log("Timeout called!");
					$('[data-toggle="tooltip"]').tooltip();
				}, 1000);
				
			});
		};
		
		function limpiarListas() {
			listaNoticias.splice(0, listaNoticias.length);
		}
		
		$scope.changeNotMod = function(not){
			$scope.notMod = not;
		}
		
		$scope.detNoticia = function(not) {
			
			json.action = "getNoticia";
			json.noticia = not;
			
			servicesPortal.getNoticia(json).then(function(response) {
				
				var noticiaDet = response.data.generalValues;	
				$scope.idcliente = noticiaDet.usuario.idcliente;
				$scope.idusuario = noticiaDet.usuario.idusuario;
				$scope.idnoticia = noticiaDet.noticia.idnoticia;
				$scope.txtTituloNot = noticiaDet.noticia.titulonot;
				$scope.txtContenidoNot = noticiaDet.noticia.textonot;

			});
		};
		
		$scope.guardarNoticia = function() {
			$("#noticia-editar .close").click()
			json.action = "setNoticia";
			json.noticia.idcliente = $scope.idcliente;
			json.noticia.idusuario = $scope.idusuario;
			json.noticia.titulonot = $scope.txtTituloNot;
			json.noticia.textonot = $scope.txtContenidoNot;
			
			servicesPortal.setNoticia(json).then(function(response) {
				json.action = "getListaNoticias";
				if(response.data > 0){
					alert("Registro actualizado satisfactoriamente");
					$scope.cargarDatos(json);
				}else{
					alert("Error al actualizar noticia");
				}
			});
		};
		
		$scope.insertarNoticia = function() {
			$("#crear-noticia .close").click()
			json.action = "addNoticia";
			json.noticia = {};
			json.noticia.idusuario = $scope.idusuario;
			json.noticia.titulonot = $scope.txtTituloNoticiaAdd;
			json.noticia.textonot = $scope.txtContenidoNoticiaAdd;
			
			servicesPortal.addNoticia(json).then(function(response) {
				json.action = "getListaNoticias";
				if(response.data > 0){
					$scope.cargarDatos(json);
				}else{
					alert("Error al agregar noticia");
				}
			});
		};
		

		$scope.eliminarNoticia= function() {
			$("#noticia-eliminar .close").click()
			json.action = "setStatusNoticia";
			json.notModificar = $scope.notMod;
			json.notModificar.activa = -1;
			servicesPortal.setStatusNoticia(json).then(function(response) {
				json.action = "getListaNoticias";
				if(response.data > 0){
					alert("Noticia eliminada satisfactoriamente");
					$scope.cargarDatos(json);
				}else{
					alert("Error al eliminar noticia");
				}
			});
		};
		
		$scope.setStatusNoticia = function(){
			$("#noticia-desactivar .close").click();
			$("#noticia-activar .close").click();
			json.action = "setStatusNoticia";
			json.proModificar = $scope.proMod;
			servicesPortal.setStatusNoticia(json).then(function(response) {
				json.action = "getListaNoticias";
				if(response.data > 0){
					$scope.cargarDatos(json);
				}else{
					alert("Error al actualizar proveedor");
				}
				
			});
		
		};
		$scope.cargarDatos(json);
		
	});