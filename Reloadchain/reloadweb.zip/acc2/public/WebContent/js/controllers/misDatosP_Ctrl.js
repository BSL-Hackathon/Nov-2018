'use strict';
	var app = angular.module("appPortal");
	/*******************************************************************************
	 * Controlador Mis Datos - Proveedor
	 */
	app.controller("misDatosP_Ctrl", function($scope, $rootScope, $window, $location, 
			servicesPortal, sharedProp) {
			
		var json = {};
		var listaObtener = "";

		$scope.cargando = false;
		$scope.currentPage = 0;
		$scope.pageSize = 10;
		listaObtener = "";

		json.currentPage = $scope.currentPage;
		json.pageSize = $scope.pageSize;
		json.listaObtener = listaObtener;
		json.action = "getMisDatos";
		
		$scope.cargarDatos = function() {
		
			servicesPortal.getMisDatos(json).then(function(response) {
				
				var misDatos = response.data.generalValues;	
				$scope.txtRut = misDatos.usuario.docideusuario;
				$scope.txtNombre = misDatos.usuario.nombre;
				$scope.txtUsuario = misDatos.usuario.usuario;
				$scope.txtEmail = misDatos.usuario.correo;
			});
			
		};
			
		$scope.cargarDatos(json);
		
	});