'use strict';
	var app = angular.module("appPortal");
	/*******************************************************************************
	 * Controlador Usuarios Compradores
	 */
	app.controller("usuarioP_Ctrl", function($scope, $rootScope, $window, $location, 
			servicesPortal, sharedProp, corporativo) {
			
		var lista = [];
		var now = moment(new Date());
		var json = {};
		var listaObtener = "";
		$scope.userMod = "";
		$scope.cargando = false;
		$scope.currentPage = 0;
		$scope.pageSize = 10;
		$scope.chkActivoAdd = true;
		$scope.rdTipoAdd = 1;
		$scope.selected = 0;

		json.currentPage = $scope.currentPage;
		json.pageSize = $scope.pageSize;
		json.listaObtener = listaObtener;
		json.action = "usuarioP";
		json.filtros = {};
		
		var date = new Date();
		
	
		$scope.cargarDatos = function() {
					
			servicesPortal.getUsuarios(json).then(function(response) {
				angular.forEach(response.data.t,function(item) {
					if(item.activo == 1){
						item.estado = "Activo";
						item.btnclass = "btn-success";
						item.cambiarEstado = "#usr-desactivar";
					}else if(item.activo == 0){
						item.estado = "Inactivo";
						item.btnclass = "btn-default";
						item.cambiarEstado = "#usr-activar";
					}
					
				});
				
				json.filtrado = false;
				$scope.usuarios = response.data.t;
				json.offSet = undefined;
				$scope.total = response.data.totalRows;
			
			});
			
		};
		
		$scope.DoCtrlPagingAct = function(text, page, pageSize, total) {
			json.currentPage = page;
			json.pageSize = pageSize;
			$scope.cargarDatos(json);
		};
		
		$scope.changeItemsToSee = function(e) {
			$('#itemsToSee').children('a').each(function() {
				if ($(this).hasClass('active')) {
					$(this).removeClass("active");
					return;
				}
			});
			$(e.currentTarget).addClass("active");
			$scope.pageSize = $(e.currentTarget).text();
			json.pageSize = $scope.pageSize;
			json.offSet = 0;
			$scope.cargarDatos(json);
		};
		
		$scope.exportarCsv = function() {
			var exportar = true;
			json.exportar = exportar;
			json.action = "exportarCsvUsuarios";
			servicesPortal
					.exportarCsvGestion(json)
					.then(
							function(response) {
								json.action = "usuarioP";
								var headers = response.headers();
								var blob = new Blob([ response.data ], {
									type : headers['content-type']
								});
								var windowUrl = (window.URL || window.webkitURL);
								var downloadUrl = windowUrl
										.createObjectURL(blob);
								var anchor = document.createElement("a");
								anchor.href = downloadUrl;
								var fileNamePattern = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
								anchor.download = fileNamePattern
										.exec(headers['content-disposition'])[1];
								document.body.appendChild(anchor);
								anchor.click();
								windowUrl.revokeObjectURL(blob);
							});
		}
		
		$scope.changeUserMod = function(user){
			$scope.userMod = user;
		}
		
		$scope.cambiarEstado = function(){
			$("#usr-desactivar .close").click();
			$("#usr-activar .close").click();
			json.action = "changeUserState";
			json.userModificar = $scope.userMod;
			servicesPortal.updateUsuario(json).then(function(response) {
				json.action = "usuarioP";
				if(response.data > 0){
					$scope.cargarDatos(json);
				}else{
					alert("Error al actualizar usuario");
				}
				
			});
		
		};
		$scope.addUser = function(){
			$("#usuario-nuevo .close").click();
			json.action = "addUser";
			json.userAdd = {};
			var user = {};
			user.nombre = $scope.txtNombreAdd;
			user.docideusuario = $scope.txtRutAdd;
			user.usuario = $scope.txtUsuarioAdd;
			user.correo = $scope.txtCorreoAdd;
			user.activo = $scope.chkActivoAdd ? 1 : 0;
			user.idrol = $scope.rdTipoAdd;
			
			json.userAdd = user;
			
			servicesPortal.actionUsuario(json).then(function(response) {
				json.action = "usuarioP";
				if(response.data > 0){
					$scope.cargarDatos(json);
				}else{
					alert("Error al ingresar usuario");
				}
				
			});
		}
		
		
		$scope.eliminar = function() {
			$("#usr-eliminar .close").click();
			json.action = "delUser";
			servicesPortal.actionUsuario({
				"idusuarios" : $scope.usuarios.filter(function(i) {
					return i.selected
				}).map(function(j) {
					return j.idusuario
				}),
				"action": json.action,
				"pageSize": json.pageSize,
				"currentPage":json.currentPage
		

			}).then(function(result) {
				alert("Se eliminaron los usuarios seleccionados");
				json.action = "usuarioP";
				$scope.cargarDatos(json);
				$scope.selected = 0;
			}, function(error) {
				alert("Error al eliminar usuarios, intente nuevamente");
			});
		}
		
		$scope.modifyUser = function(){
			$("#usuario-editar .close").click();
			json.action = "modifyUser";
			json.userMod = $scope.userMod;
			
			json.userMod.activo = $scope.chkActivoMod ? 1 : 0;  
			
			servicesPortal.setUser(json).then(function(response){
				json.action = "usuarioP";
				if(response.data.codigo == 200){
					alert(response.data.mensaje);
					$scope.cargarDatos(json);
				}else{
					alert(response.data.mensaje);
				}
			});
		}
			
		$scope.toggleAll = function() {
			var list = $scope.usuarios;
			var toggleStatus = $scope.isAllSelected;
			list.forEach(function(item) {
				item.selected = toggleStatus;
			});
			
			if ($scope.isAllSelected) {
				$scope.selected = $scope.usuarios.length;

			} else {
				$scope.selected = 0;
			}
		}
		
		$scope.optionToggled = function(current) {
			var list = $scope.usuarios;

			$scope.isAllSelected = list.every(function(item) {
				return item.selected;
			});

		
			if (current.selected) {
				$scope.selected += 1;
			} else {
				$scope.selected -= 1;
			}
		}
		
		function limpiarListas() {
			$scope.usuarios.splice(0, usuarios.length);
		}
		
		$scope.reseteoPwd = function() {
			json.action = "reseteoPwdUsers";
			json.usuarioReset = $scope.userMod;
			
			servicesPortal.setUser(json).then(function(response) {
				json.action = "usuarioP";
				if(response.data > 0){
					alert("Se ha enviado correo para resetear password");
					$scope.cargarDatos(json);
				}else{
					alert("Error al enviar correo de reseteo de password");
				}
			});
		};
		
		$scope.cargarDatos(json);

	});
