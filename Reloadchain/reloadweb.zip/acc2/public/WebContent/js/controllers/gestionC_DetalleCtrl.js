'use strict';
var app = angular.module("appPortal");
/*******************************************************************************
 * Controlador Detalle Documento Gestion
 */
app.controller("gestionC_DetalleCtrl", function($scope, $rootScope, $window, $location, servicesPortal, sharedProp, $sce) {
    var json = sharedProp.getJsonFiltrosGestion();
    if (json == undefined || json == null) {
      $location.url('/gestionComprador');
      return;
    }

    $scope.atras = function() {
      json.action = "gestionDocumentalC";
      json.docDetalle = undefined;
      sharedProp.setJsonFiltrosGestion(json);
      $location.url('/gestionComprador');
    }

    var soloSii = false;
    $scope.folio = json.docDetalle.folio;
    $scope.urlPdf = json.docDetalle.urlPdf;
    var documento = json.docDetalle;
    $scope.documento = documento;

    soloSii = documento.crucesii == "Solo SII" ? true : false; 
    
    if (!soloSii) {
      json.action = "getHistoriaDocumentoById";
      //  var respuesta = response.data.respuesta;
        
        //$scope.urlPdf = respuesta.urlPdf;
        
        // Acuse Recibo
        if(documento.documentodetalle.acuserecibo == 1) {
        	$scope.acuseRecibo = "Recibido";
        	$("#acuseRecibo").addClass("label-success");
        }else if(documento.documentodetalle.acuserecibo == -1) {
        	$scope.acuseRecibo = "Error";
        	$("#acuseRecibo").addClass("label-danger");
        }else{
        	$("#acuseRecibo").addClass("label-default");
            $scope.acuseRecibo = "No disponible";
        }	
        // acise recibo comercial
        
        if(documento.documentodetalle.acusearc == 1) {
        	$scope.acuseComercial = "Recibido";
            $("#acuseComercial").addClass("label-success");
        }else if(documento.documentodetalle.acusearc == 2) {
        	$scope.acuseComercial = "Rechazado";
            $("#acuseComercial").addClass("label-danger");
        }else{
        	$scope.acuseComercial = "No disponible";
            $("#acuseComercial").addClass("label-default");
        }
        
        //Ley
        if(documento.documentodetalle.acuseley == 1) {
        	$scope.reciboMercaderia = "Recibido";
            $("#reciboMercaderia").addClass("label-success");
        }else if(documento.documentodetalle.acuseley == -1) {
        	$scope.reciboMercaderia = "Error";
            $("#reciboMercaderia").addClass("label-danger");
        }else{
        	$scope.reciboMercaderia = "No recibido";
            $("#reciboMercaderia").addClass("label-default");
        }
        
        var evento = {};
        $scope.evento = evento;
        switch(documento.documentodetalle.acusewsreclamacion){
			case 0: evento.class_ = "label-pend"; "N/D"; evento.glosa = "No disponible";  break;
			case 1: evento.class_ = "label-rec"; evento.glosa = "RCD"; break;
			case 2: evento.class_ = "label-acep"; evento.glosa = "ERM"; break;
			case 3: evento.class_ = "label-rec"; evento.glosa = "RFP"; break;
			case 4: evento.class_ = "label-rec"; evento.glosa = "RFT"; break;
			
			default: evento.class_ = "label-pend"; evento.glosa = "No disponible";

		}
        


//        if(documento.enppl == 1 && documento.ensii == 1){
//        	documento.crucesii = "SII & PPL";
//		}else if(documento.enppl == 1 && documento.ensii == 0){
//			documento.crucesii = "Solo PPL";
//		}else if(documento.ensii == 1 && documento.enppl == 0){
//			documento.crucesii = "Solo SII";
//		}
        
        
        json.offSet = undefined;       
        json.documento = documento;
        var date;
        var respuesta = {};
        servicesPortal.getHistoriaDocumentoById(json).then(function(response){
        	respuesta.listaDocreclog = response.data.t;


        	angular.forEach(response.data.t,function(item) {
//                	date = new Date(item.drlinsdate.year,item.drlinsdate.month,item.drlinsdate.dayOfMonth,
//                			item.drlinsdate.hourOfDay,item.drlinsdate.minute,item.drlinsdate.second,0);
                	date = new Date(item.drlinsdatets);
                	item.drlinsdate = formatearFechaTimestamp(date);
        	});
        	
            $scope.observaciones = respuesta.listaDocreclog;
            
            if(!angular.isUndefined(response.data.generalValues)){
            	$scope.urlPublica = response.data.generalValues.urlPublica;
            }
            
        });
    };

function formatearFechaTimestamp(date) {
  var toFormat = moment(date);
  return toFormat.format('DD/MM/YYYY hh:mm:ss A');
}
$scope.trustSrc = function(src) {
return $sce.trustAsResourceUrl(src);
}

$scope.copyToClipboard = function(elemento){
	var $temp = $("<input>")
	$("body").append($temp);
	$temp.val($(elemento).val()).select();
	document.execCommand("copy");
	$temp.remove();
}


});
