	'use strict';
	var app = angular.module("appPortal");
	/*******************************************************************************
	 * Controlador Proveedores - Compradores
	 */
	app.controller("contactosP_Ctrl", function($scope, $rootScope, $window, $location, 
			servicesPortal, sharedProp, corporativo) {
			
		var listaContactos = [];
		var now = moment(new Date());
		var json = {};
		var listaObtener = "";
		$scope.contAux ={};
		$scope.selected = 0;


		$scope.cargando = false;
		$scope.currentPage = 0;
		$scope.pageSize = 10;
		listaObtener = "contactos";

		json.currentPage = $scope.currentPage;
		json.pageSize = $scope.pageSize;
		json.listaObtener = listaObtener;
		json.action = "getListaContactos";
		json.filtros = {};
		
		var date = new Date();
		
		
		$scope.cargarDatos = function() {
		
			if (listaContactos != undefined && listaContactos.length > 0) {
				limpiarListas();
			}
		
			servicesPortal.getListaContactos(json).then(function(response) {
				
				listaContactos = response.data.t;
		
				json.filtrado = false;
				$scope.listaContactos = listaContactos;
				json.offSet = undefined;
				
				setTimeout(function() {
					console.log("Timeout called!");
					$('[data-toggle="tooltip"]').tooltip();
				}, 1000);
				
			});
		};
		
		$scope.changeContMod = function(cont){
			$scope.contAux = cont;
			$scope.txtNombreEdit = cont.nombre;
			$scope.txtCorreoEdit = cont.email;
		}
				
		$scope.editar = function() {
			$("#contacto-editar .close").click();
			json.action = "setContacto";
			json.contacto = $scope.contAux;
			json.contacto.nombre = $scope.txtNombreEdit;
			json.contacto.email = $scope.txtCorreoEdit;
			
			servicesPortal.setContacto(json).then(function(response) {
				json.action = "getListaContactos";
				if(response.data > 0){
					alert("Registro actualizado satisfactoriamente");
					$scope.txtNombreEdit = undefined;
					$scope.txtCorreoEdit = undefined;
					$scope.cargarDatos(json);
				}else{
					alert("Error al actualizar contacto");
				}
			});
		};
		
		$scope.agregar = function() {
			$("#contacto-nuevo .close").click();
			json.action = "addContacto";
			json.contacto = {};
			json.contacto.nombre = $scope.txtNombreAdd;
			json.contacto.email = $scope.txtCorreoAdd;
			
			servicesPortal.addContacto(json).then(function(response) {
				if(response.data > 0){
					$scope.txtNombreAdd = undefined;
					$scope.txtCorreoAdd = undefined;
					json.action = "getListaContactos";
					$scope.cargarDatos(json);
				}else{
					alert("Error al agregar contacto");
				}
			});
		};
		
		$scope.eliminar = function() {
			$("#usr-eliminar .close").click();
			json.action = "removeContacto";
			servicesPortal.removeContacto({
				"idlistacontacto" : $scope.listaContactos.filter(function(i) {
					return i.selected
				}).map(function(j) {
					return j.idlistacontacto
				}),
				"action": json.action,
				"pageSize": json.pageSize,
				"currentPage":json.currentPage

			}).then(function(result) {
				alert("Se eliminaron los contactos seleccionados");
				json.action = "getListaContactos";
				$scope.cargarDatos(json);
				$scope.selected = 0;
			}, function(error) {
				alert("Error al eliminar usuarios, intente nuevamente");
			});
		}
			
		$scope.toggleAll = function() {
			var list = $scope.listaContactos;
			var toggleStatus = $scope.isAllSelected;
			list.forEach(function(item) {
				item.selected = toggleStatus;
			});
			
			if ($scope.isAllSelected) {
				$scope.selected = $scope.listaContactos.length;

			} else {
				$scope.selected = 0;
			}
		}
		
		$scope.optionToggled = function(current) {
			var list = $scope.listaContactos;

			$scope.isAllSelected = list.every(function(item) {
				return item.selected;
			});

		
			if (current.selected) {
				$scope.selected += 1;
			} else {
				$scope.selected -= 1;
			}
		}
		function limpiarListas() {
			listaContactos.splice(0, listaContactos.length);
		}
		
		$scope.DoCtrlPagingAct = function(text, page, pageSize, total) {
			json.currentPage = page;
			json.pageSize = pageSize;
			$scope.cargarDatos(json);
		};

		$scope.changeItemsToSee = function(e) {
			$('#itemsToSee').children('a').each(function() {
				if ($(this).hasClass('active')) {
					$(this).removeClass("active");
					return;
				}
			});
			$(e.currentTarget).addClass("active");
			$scope.pageSize = $(e.currentTarget).text();
			json.pageSize = $scope.pageSize;
			json.offSet = 0;
			$scope.cargarDatos(json);
		};

		$scope.exportarCsv = function() {
			var exportar = true;
			json.exportar = exportar;
			json.action = "exportarCsvContactos";
			servicesPortal
					.exportarCsvGestion(json)
					.then(
							function(response) {
								json.action = "getListaContactos";
								var headers = response.headers();
								var blob = new Blob([ response.data ], {
									type : headers['content-type']
								});
								var windowUrl = (window.URL || window.webkitURL);
								var downloadUrl = windowUrl
										.createObjectURL(blob);
								var anchor = document.createElement("a");
								anchor.href = downloadUrl;
								var fileNamePattern = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
								anchor.download = fileNamePattern
										.exec(headers['content-disposition'])[1];
								document.body.appendChild(anchor);
								anchor.click();
								windowUrl.revokeObjectURL(blob);
							});
		}
		
		//jsonReclamados = undefined;
		$scope.cargarDatos(json);
		
	});
