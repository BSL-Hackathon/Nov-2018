	'use strict';
	var app = angular.module("appPassMailing");
	/*******************************************************************************
	 * Controlador Pass Mailing
	 */
	app.controller("passMailingCtrl", function($scope, $rootScope, $window, $location, servicesPassword) {
		
		var largo = false;
		var mayus = false;
		var number = false;
		var charEspecial = false;
		var coincidencia = false;
		
			
		function gpbn(name) {
		    var match = RegExp('[?&]' + name + '=([^&]*)').exec(window.location.search);
		    return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
		 }
		
		var id = gpbn("show");
		
		if(id == "p"){
			$scope.admin = true;
		}else if(id == "u"){
			$scope.user = true;
		}else if(id == "c"){
			$scope.pass = true;
		}
		
		
		$('#passRepeat').keyup(function() {
			var pswd = $(this).val();

			if ( pswd.length < 8 ) {
			    $('#length').removeClass('valid').addClass('invalid');
			    largo = false;
			    
			} else {
			    $('#length').removeClass('invalid').addClass('valid');
			    largo = true;
			}
			
			//validate letter
			if ( pswd.match(/[A-z]/) ) {
			    $('#letter').removeClass('invalid').addClass('valid');
			    
			} else {
			    $('#letter').removeClass('valid').addClass('invalid');
			}

			//validate capital letter
			if ( pswd.match(/[A-Z]/) ) {
			    $('#capital').removeClass('invalid').addClass('valid');
			    mayus = true;
			} else {
			    $('#capital').removeClass('valid').addClass('invalid');
			}

			//validate number
			if ( pswd.match(/\d/) ) {
			    $('#number').removeClass('invalid').addClass('valid');
			    number = true;
			} else {
			    $('#number').removeClass('valid').addClass('invalid');
			    number = false;
			}
			
			//validate special character 
			if ( pswd.match(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi) ) {
			    $('#especial').removeClass('invalid').addClass('valid');
			    charEspecial = true;
			} else {
			    $('#especial').removeClass('valid').addClass('invalid');
			    charEspecial = false;
			}
			
			//concidencia de password
			if ( $(this).val() == $("#pass").val() ) {
			    $('#coincidencia').removeClass('invalid').addClass('valid');
			    coincidencia = true;
			} else {
			    $('#coincidencia').removeClass('valid').addClass('invalid');
			    coincidencia = false;
			}
			
			

		}).focus(function() {
		    $('#pswd_info').show();
		}).blur(function() {
		    $('#pswd_info').hide();
		});

		$('#pass').keyup(function() {
			var pswd = $(this).val();
			
			if ( pswd.length < 8 ) {
			    $('#length').removeClass('valid').addClass('invalid');
			    largo = false;
			    
			} else {
			    $('#length').removeClass('invalid').addClass('valid');
			    largo = true;
			}
			
			//validate letter
			if ( pswd.match(/[A-z]/) ) {
			    $('#letter').removeClass('invalid').addClass('valid');
			    
			} else {
			    $('#letter').removeClass('valid').addClass('invalid');
			}

			//validate capital letter
			if ( pswd.match(/[A-Z]/) ) {
			    $('#capital').removeClass('invalid').addClass('valid');
			    mayus = true;
			} else {
			    $('#capital').removeClass('valid').addClass('invalid');
			}

			//validate number
			if ( pswd.match(/\d/) ) {
			    $('#number').removeClass('invalid').addClass('valid');
			    number = true;
			} else {
			    $('#number').removeClass('valid').addClass('invalid');
			    number = false;
			}
			
			//validate special character 
			if ( pswd.match(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi) ) {
			    $('#especial').removeClass('invalid').addClass('valid');
			    charEspecial = true;
			} else {
			    $('#especial').removeClass('valid').addClass('invalid');
			    charEspecial = false;
			}
			
			//concidencia de password
			if ( $(this).val() == $("#passRepeat").val() ) {
			    $('#coincidencia').removeClass('invalid').addClass('valid');
			    coincidencia = true;
			} else {
			    $('#coincidencia').removeClass('valid').addClass('invalid');
			    coincidencia = false;
			}

		}).focus(function() {
		    $('#pswd_info').show();
		}).blur(function() {
		    $('#pswd_info').hide();
		});
		
		
		$scope.cambiarPassword = function(){
			
			if( !(coincidencia && largo &&
					mayus && charEspecial) ){
				$("#pswd_info").show();
				$("#pswd_info").focus();
				return;
			}
			
			var json = {};
			json.currentPage = 0;
			json.pageSize = 10;
			json.action = "cambiarPassword";
			json.filtros = {};
			json.filtros.password = $("#pass").val();
			json.filtros.idPw = gpbn("pm");
				
			
			servicesPassword.cambiarPassword(json).then(function(response){
				if(response.data == 'OK'){
					setTimeout(function(){ window.location.href = window.location.origin + "/PortalProveedores/Logout"; }, 1500);
					alert("Cambio realizado con exito. Redireccionando a Login...");
				}else{
					alert(response.data);
				}
			});
		}
		
		
	});
