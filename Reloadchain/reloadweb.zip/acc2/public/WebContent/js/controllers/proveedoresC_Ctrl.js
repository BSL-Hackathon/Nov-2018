	'use strict';
	var app = angular.module("appPortal");
	/*******************************************************************************
	 * Controlador Proveedores - Compradores
	 */
	app.controller("proveedoresC_Ctrl", function($scope, $rootScope, $window, $location, 
			servicesPortal, sharedProp, corporativo) {
			
		var listaProveedores = [];
		var now = moment(new Date());
		var json = {};
		var listaObtener = "";
		$scope.proMod = "";
		$scope.idcliente = 0;
		$scope.idusuario = 0;
		$scope.selected = 0;
		$scope.proSel;

		$scope.cargando = false;
		$scope.currentPage = 0;
		$scope.pageSize = 10;
		listaObtener = "proveedores";

		json.currentPage = $scope.currentPage;
		json.pageSize = $scope.pageSize;
		json.listaObtener = listaObtener;
		json.action = "getListaProveedores";
		json.filtros = {};
		
		var date = new Date();
		
		$rootScope.$on('refrescar', function(event, args) {
			$scope.cargarDatos(json);
		});
		
		$scope.cargarDatos = function() {
		
			if (listaProveedores != undefined && listaProveedores.length > 0) {
				limpiarListas();
			}
		
			servicesPortal.getListaProveedores(json).then(function(response) {
				angular.forEach(response.data.t,function(item) {
					
					if (item.activo == 1) {
						item.activo = "Activo";
						item.btnclass = "btn-success";
						item.accion = "#proveedor-desactivar";
					} else {
						item.activo = "Inactivo";
						item.btnclass = "btn-default";
						item.accion = "#proveedor-activar";
					}
						
				});
				
				if (json.filtrado) {
					$scope.total = response.data.rowsReturned == 0 ? 1
							: response.data.rowsReturned;
				} else {
					$scope.total = response.data.totalRows;
				}
		
				$scope.rows = response.data.totalRows;
				listaProveedores = response.data.t;
		
				json.filtrado = false;
				$scope.listaProveedores = listaProveedores;
				json.offSet = undefined;
				
				setTimeout(function() {
					console.log("Timeout called!");
					$('[data-toggle="tooltip"]').tooltip();
				}, 1000);
				
			});
		};
		
		$scope.changeProMod = function(pro){
			$scope.proMod = pro;
		}
		
		$scope.cambiarEstado = function(){
			$("#proveedor-desactivar .close").click();
			$("#proveedor-activar .close").click();
			json.action = "setStatusProveedor";
			json.proModificar = $scope.proMod;
			servicesPortal.setStatusProveedor(json).then(function(response) {
				json.action = "getListaProveedores";
				if(response.data > 0){
					$scope.cargarDatos(json);
				}else{
					alert("Error al actualizar proveedor");
				}
				
			});
		
		};
		
		$scope.detalle = function(pro) {
			
			json.action = "getProveedor";
			json.cliente = pro;
			$scope.proSel = pro;
			
			servicesPortal.getProveedor(json).then(function(response) {
				
				var misDatos = response.data.generalValues;	
				$scope.idcliente = misDatos.cliente.idcliente;
				$scope.txtERut = misDatos.cliente.docidecliente;
				$scope.txtERazonSocial = misDatos.cliente.razonsocial;
				$scope.idusuario = misDatos.usuario.idusuario;
				$scope.txtEUsuarioNombre = misDatos.usuario.nombre;
				$scope.txtEUsuarioUsuario = misDatos.usuario.usuario;
				$scope.txtECorreo = misDatos.usuario.correo;
			});
		};
		
		$scope.guardar = function() {
			$("#proveedor-editar .close").click()
			json.action = "setProveedor";
			json.cliente.idcliente = $scope.idcliente
			json.cliente.rutEmisor = $scope.txtERut;
			json.cliente.idusuario = $scope.idusuario;
			json.cliente.nombreusuario = $scope.txtEUsuarioNombre;
			json.cliente.correousuario = $scope.txtECorreo;
			
			servicesPortal.setProveedor(json).then(function(response) {
				json.action = "getListaProveedores";
				if(response.data > 0){
					alert("Registro actualizado satisfactoriamente");
					$scope.cargarDatos(json);
				}else{
					alert("Error al actualizar proveedor");
				}
			});
		};
		
		$scope.reseteoPwd = function() {
			json.action = "reseteoPwd";
			json.cliente = $scope.proSel;
			
			servicesPortal.setProveedor(json).then(function(response) {
				json.action = "getListaProveedores";
				if(response.data > 0){
					alert("Se ha enviado correo para resetear password");
					$scope.cargarDatos(json);
				}else{
					alert("Error al enviar correo de reseteo de password");
				}
			});
		};
		
		$scope.insertar = function() {
			$("#proveedor-nuevo .close").click()
			json.action = "addProveedor";
			json.cliente = {};
			json.cliente.rutEmisor = $scope.txtRutProveedorAdd;
			json.cliente.nombreusuario = $scope.txtNombreAdminAdd;
			json.cliente.usuario = $scope.txtUserAdminAdd;
			json.cliente.correousuario = $scope.txtCorreoAdminAdd;
			
			servicesPortal.setProveedor(json).then(function(response) {
				json.action = "getListaProveedores";
				if(response.data.codigo == 200){
					$scope.cargarDatos(json);
				}else{
					alert(response.data.mensaje);
				}
			});
		};
		
		$scope.eliminar = function() {
			$("#usr-eliminar .close").click();
			json.action = "delProveedor";
			servicesPortal.actionUsuario({
				"idproveedores" : $scope.listaProveedores.filter(function(i) {
					return i.selected
				}).map(function(j) {
					return j.idcliente
				}),
				"action": json.action,
				"pageSize": json.pageSize,
				"currentPage":json.currentPage
		

			}).then(function(result) {
				alert("Se eliminaron los proveedores seleccionados");
				json.action = "getListaProveedores";
				$scope.cargarDatos(json);
				$scope.selected = 0;
			}, function(error) {
				alert("Error al eliminar proveedores, intente nuevamente");
			});
		}
			
		$scope.toggleAll = function() {
			var list = $scope.listaProveedores;
			var toggleStatus = $scope.isAllSelected;
			list.forEach(function(item) {
				item.selected = toggleStatus;
			});
			
			if ($scope.isAllSelected) {
				$scope.selected = $scope.listaProveedores.length;

			} else {
				$scope.selected = 0;
			}
		}
		
		$scope.optionToggled = function(current) {
			var list = $scope.listaProveedores;

			$scope.isAllSelected = list.every(function(item) {
				return item.selected;
			});

		
			if (current.selected) {
				$scope.selected += 1;
			} else {
				$scope.selected -= 1;
			}
		}
		
		function limpiarListas() {
			listaProveedores.splice(0, listaProveedores.length);
		}
		
		$scope.DoCtrlPagingAct = function(text, page, pageSize, total) {
			json.currentPage = page;
			json.pageSize = pageSize;
			$scope.cargarDatos(json);
		};

		$scope.changeItemsToSee = function(e) {
			$('#itemsToSee').children('a').each(function() {
				if ($(this).hasClass('active')) {
					$(this).removeClass("active");
					return;
				}
			});
			$(e.currentTarget).addClass("active");
			$scope.pageSize = $(e.currentTarget).text();
			json.pageSize = $scope.pageSize;
			json.offSet = 0;
			$scope.cargarDatos(json);
		};

		$scope.exportarCsv = function() {
			var exportar = true;
			json.exportar = exportar;
			json.action = "exportarCsvProveedores";
			servicesPortal
					.exportarCsvGestion(json)
					.then(
							function(response) {
								json.action = "getListaProveedores";
								var headers = response.headers();
								var blob = new Blob([ response.data ], {
									type : headers['content-type']
								});
								var windowUrl = (window.URL || window.webkitURL);
								var downloadUrl = windowUrl
										.createObjectURL(blob);
								var anchor = document.createElement("a");
								anchor.href = downloadUrl;
								var fileNamePattern = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
								anchor.download = fileNamePattern
										.exec(headers['content-disposition'])[1];
								document.body.appendChild(anchor);
								anchor.click();
								windowUrl.revokeObjectURL(blob);
							});
		}
		
		//jsonReclamados = undefined;
		$scope.cargarDatos(json);
		
	});
