'use strict';
	var app = angular.module("appPortal");
	/*******************************************************************************
	 * Controlador Gestion Documental
	 */
	app.controller("gestionP_Ctrl", function($scope, $rootScope, $window, $location, 
			servicesPortal, sharedProp) {
			
		var listaDocumentos = [];
		var now = moment(new Date());
		var json = {};
		var listaObtener = "";

		$scope.datePattern=/^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/i;
		$scope.cargando = false;
		$scope.currentPage = 0;
		$scope.pageSize = 10;
		listaObtener = "documentos";

		json.currentPage = $scope.currentPage;
		json.pageSize = $scope.pageSize;
		json.listaObtener = listaObtener;
		json.action = "gestionDocumentalP";
		json.filtros = sharedProp.getJsonFiltrosGestion();
		if(angular.isUndefined(json.filtros)){
			json.filtros = {};
		}
		
		var date = new Date();

		$scope.cargarDatos = function() {
		
			if (listaDocumentos != undefined && listaDocumentos.length > 0) {
				limpiarListas();
			}
		
			servicesPortal.getDocumentosByCoId(json).then(function(response) {
				angular.forEach(response.data.t,function(item) {
					
					if (item.fechaemision != undefined) {
						date = null;
						date = new Date(
								item.fechaemision);
						item.fechaemision = Date.parse(item.fechaemision);
					}
					
					if (item.fechainsercionasp != undefined) {
						date = null;
						date = new Date(
								item.fechainsercionasp);
						item.fechainsercionasp = Date.parse(date);
					}
					
					if(item.enppl == 1 && item.ensii == 1){
						item.crucesii = "SII & PPL";
					}else if(item.enppl == 1 && item.ensii == 0){
						item.crucesii = "Solo PPL";
					}else if(item.ensii == 1 && item.enppl == 0){
						item.crucesii = "Solo SII";
					}
					
					
					if(item.documentodetalle != undefined && item.documentodetalle != null){
						switch(item.documentodetalle.acuserecibo){
							case -1: item.atclass = "label-rec-tipo"; break;
							case 0: item.atclass = "label-pend-tipo"; break;
							case 1: item.atclass = "label-acep-tipo"; break;
							default: item.atclass = "label-pend-tipo";
						}
						
						switch(item.documentodetalle.acusearc){
							case 2: item.arcclass = "label-rec-tipo"; break;
							case 0: item.arcclass = "label-pend-tipo"; break;
							case 1: item.arcclass = "label-acep-tipo"; break;
							default: item.arcclass = "label-pend-tipo";
						} 
						
					
						
						
						if(item.documentodetalle.acusewsreclamacion != 0 ||
						 item.documentodetalle.acuseley != 0){
							
							if(item.documentodetalle.acusewsreclamacion != 0){
								
								switch(item.documentodetalle.acusewsreclamacion){
									case 0: item.stclass = "label-pend"; item.stdesc = "N/D"; item.stglosa = "No disponible";  break;
									case 1: item.stclass = "label-rec"; item.stdesc = "Reclamo al Contenido del Documento"; item.stglosa = "RCD"; break;
									case 2: item.stclass = "label-acep"; item.stdesc = "Otorga Recibo de Mercadería"; item.stglosa = "ERM"; break;
									case 3: item.stclass = "label-rec"; item.stdesc = "Reclamo por Falta Parcial de Mercaderías"; item.stglosa = "RFP"; break;
									case 4: item.stclass = "label-rec"; item.stdesc = "Reclamo por Falta Total de Mercaderías"; item.stglosa = "RFT"; break;
									
									default: item.stclass = "label-pend"; item.stdesc = "N/D"; item.stglosa = "No disponible";						
								}
							}else if(item.documentodetalle.acuseley != 0){
								switch(item.documentodetalle.acuseley){
									case 1: item.stclass = "label-acep"; item.stdesc = "Otorga Recibo de Mercadería"; item.stglosa = "ERM"; break;
									default: item.stclass = "label-pend"; item.stdesc = "N/D"; item.stglosa = "No disponible";
								}
							}
							 
						}else{
									item.stclass = "label-pend"; item.stdesc = "N/D"; item.stglosa = "No disponible";
							}	
						 
						
						switch(item.estadopago){
							case 1: item.pagoGlosa = "Procesado"; item.pagoClass = "label-default"; break;
							case 2: item.pagoGlosa = "Pagado"; item.pagoClass = "label-success"; break;
							default: item.pagoGlosa = "En proceso"; item.pagoClass = "label-default"; break;
						}
						
						
						if (item.fechapago != undefined) {
							date = null;
							date = new Date(
									item.fechapago);
							item.fechapago = Date.parse(item.fechapago);
						}
						
						/*switch(item.documentodetalle.formapago){
							case 1:  item.formaPago = "Vale Vista"; break;
							case 2:  item.formaPago = "Cheque"; break;
							case 3:  item.formaPago = "Transferencia"; break;
							case 4:  item.formaPago = "Efectivo"; break;
							case 5:  item.formaPago = "Cr\u00E9dito"; break;
							default: item.formaPago = "--";
						}*/
						switch (item.medioPago) {
							case 1:  item.medioPago = "Vale Vista"; break;
							case 2:  item.medioPago = "Cheque"; break;
							case 3:  item.medioPago = "Transferencia"; break;
							case 4:  item.medioPago = "Efectivo"; break;
							case 5:  item.medioPago = "Cr\u00E9dito"; break;
							default: item.medioPago = "--";
						}
						
						if(item.documentodetalle.fechaautorizacion != null){
                            date = null;
                            date = new Date(item.documentodetalle.fechaautorizacion);
                            var str = formatearFechaTimestamp(date);

                            var fechaAut = str.toString().split(" ");
                            item.documentodetalle.fechaAut = fechaAut[0];
                            item.documentodetalle.fechaAutHr = fechaAut[1];
						}
						
					}
						
				});
				
				if (json.filtrado) {
					$scope.total = response.data.rowsReturned == 0 ? 1
							: response.data.rowsReturned;
				} else {
					$scope.total = response.data.totalRows;
				}
		
				$scope.rows = response.data.totalRows;
				listaDocumentos = response.data.t;
		
				json.filtrado = false;
				$scope.listaDocumentos = listaDocumentos;
				json.offSet = undefined;
				
				setTimeout(function() {
					console.log("Timeout called!");
					$('[data-toggle="tooltip"]').tooltip();
				}, 1000);
				
			});
		};
		
		
		
		
		$scope.toggleAll = function() {
			var list = $scope.listaDocumentos;
			var toggleStatus = $scope.isAllSelected;
			list.forEach(function(item) {
				item.selected = toggleStatus;
			});

			if ($scope.isAllSelected) {
				$scope.selected = $scope.listaDocumentos.length;

				$scope.montoSeleccionados = list.reduce(function(accumulator, currentValue,
						currentIndex, array) {
					var current = Number
							.parseInt(currentValue.montototal);
					return accumulator + current;
				}, 0);

			} else {
				$scope.selected = 0;
				$scope.montoSeleccionados = 0;
			}
		}
		
		$scope.optionToggled = function(current) {
			var list = $scope.listaDocumentos;

			$scope.isAllSelected = list.every(function(item) {
				return item.selected;
			});

		
			if (current.selected) {
				$scope.selected += 1;
				$scope.montoSeleccionados += current.montototal;
			} else {
				$scope.selected -= 1;
				$scope.montoSeleccionados -= current.montototal;
			}
		}
		
		function formatearFechaTimestamp(date) {
			var toFormat = moment(date);
			return toFormat.format('DD/MM/YYYY hh:mm:ss A');
		}
		
		
		function limpiarListas() {
			listaDocumentos.splice(0, listaDocumentos.length);
		}
		
		
		$scope.filtrar = function() {
			var filtros = {};
			var isFiltro = false;
			if ($scope.filtroRutReceptor != undefined && $scope.filtroRutReceptor != "") {
				filtros = {
					"rutReceptor" : $scope.filtroRutReceptor
				}
				//isFiltro = true;
			}
			
			if ($scope.filtroTipoDte != undefined) {
				var tiposDte = [];
				$scope.filtroTipoDte.forEach(function(key, value) {
					tiposDte.push(key);
				});
				filtros['tiposDte'] = tiposDte;
			}

			if ($scope.filtroFolioDesde != undefined || $scope.filtroFolioHasta != undefined) {
				if ($scope.filtroFolioHasta != "" && $scope.filtroFolioDesde == "") {
					alert("Debe ingresar \"Folio desde\"");
					return;
				}
				if ($scope.filtroFolioHasta != "" && $scope.filtroFolioHasta == "") {
					alert("Debe ingresar \"Folio hasta\"");
					return;
				}
				if ($scope.filtroFolioDesde != "" && $scope.filtroFolioHasta != "") {
					//isFiltro = true;
					filtros['folioDesde'] = $scope.filtroFolioDesde;
					filtros['folioHasta'] = $scope.filtroFolioHasta;
				}
			}

			if ($scope.filtroMontoDesde != undefined || $scope.filtroMontoHasta != undefined) {
				if ($scope.filtroMontoHasta != "" && $scope.filtroMontoDesde == "") {
					alert("Debe ingresar \"Monto desde\"");
					return;
				}
				if ($scope.filtroMontoDesde != "" && $scope.filtroMontoHasta == "") {
					alert("Debe ingresar \"Monto hasta\"");
					return;
				}
				if ($scope.filtroMontoDesde != "" && $scope.filtroMontoHasta != "") {
					//isFiltro = true;
					filtros['montoDesde'] = $scope.filtroMontoDesde;
					filtros['montoHasta'] = $scope.filtroMontoHasta;
				}
			}

			if ($("#fecha_emision_desde").val() != "" && $("#fecha_emision_hasta").val() != "") {
				//isFiltro = true;
				filtros['fechaEmisionDesde'] = $("#fecha_emision_desde").val();
				filtros['fechaEmisionHasta'] = $("#fecha_emision_hasta").val();
			}
			
			if ($("#fecha_autorizacion_desde").val() != "" && $("#fecha_autorizacion_hasta").val() != "") {
				//isFiltro = true;
				filtros['fechaAutorizacionDesde'] = $("#fecha_autorizacion_desde").val();
				filtros['fechaAutorizacionHasta'] = $("#fecha_autorizacion_hasta").val();
			}			
			
			if($("#fecha_recepcion_desde").val() != "" && $("#fecha_recepcion_hasta").val() != "") {
				//isFiltro = true;
				filtros['fechaRecepcionDesde'] = $("#fecha_recepcion_desde").val();
				filtros['fechaRecepcionHasta'] = $("#fecha_recepcion_hasta").val();
			}			
						
			if ($scope.filtroCuadratura != undefined && $scope.filtroCuadratura.length > 0) {
				var listaCuadratura = [];
				$scope.filtroCuadratura.forEach(function(key, value) {
					listaCuadratura.push(key);
				});
				filtros['listaCuadratura'] = listaCuadratura;
			}

			json.filtros = filtros;
			json.filtrado = isFiltro;
			isFiltro = undefined;
			$scope.currentPage = 1;
			json.currentPage = $scope.currentPage;
			$scope.cargarDatos(json);
		}
		
		$scope.DoCtrlPagingAct = function(text, page, pageSize, total) {
			json.currentPage = page;
			json.pageSize = pageSize;
			$scope.cargarDatos(json);
		};

		$scope.changeItemsToSee = function(e) {
			$('#itemsToSee').children('a').each(function() {
				if ($(this).hasClass('active')) {
					$(this).removeClass("active");
					return;
				}
			});
			$(e.currentTarget).addClass("active");
			$scope.pageSize = $(e.currentTarget).text();
			json.pageSize = $scope.pageSize;
			json.offSet = 0;
			$scope.cargarDatos(json);
		};

		$scope.clearFilter = function() {
			//
			$scope.filtroFolioDesde = undefined;
			$scope.filtroFolioHasta = undefined
			$scope.filtroTipoDte = undefined;
			$scope.filtroRutReceptor = undefined;
			$scope.filtroFechaEmisionDesde = undefined;
			$scope.filtroFechaEmisionHasta = undefined;
			$scope.filtroFechaAutorizacionDesde = undefined;
			$scope.filtroFechaAutorizacionHasta = undefined;
			$scope.filtroFechaRecepcionDesde = undefined;
			$scope.filtroFechaRecepcionnHasta = undefined;;
			$scope.filtroMontoDesde = undefined;
			$scope.filtroCanal = [];
			$scope.filtrar();
		}
		
		
		$scope.detalle = function(doc) {
			json.docDetalle = doc;
			sharedProp.setJsonFiltrosGestion(json);
			$location.url('/gestionProveedorDetalle');
		}
		
		
		$scope.exportarCsv = function() {
			var exportar = true;
			json.exportar = exportar;
			json.action = "exportarCsvGestion";
			servicesPortal
					.exportarCsvGestion(json)
					.then(
							function(response) {
								json.action = "gestionDocumentalP";
								var headers = response.headers();
								var blob = new Blob([ response.data ], {
									type : headers['content-type']
								});
								var windowUrl = (window.URL || window.webkitURL);
								var downloadUrl = windowUrl
										.createObjectURL(blob);
								var anchor = document.createElement("a");
								anchor.href = downloadUrl;
								var fileNamePattern = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/
								anchor.download = fileNamePattern
										.exec(headers['content-disposition'])[1];
								document.body.appendChild(anchor);
								anchor.click();
								windowUrl.revokeObjectURL(blob);
							});
		}
		
		//jsonReclamados = undefined;
		$scope.cargarDatos(json);
		
		
		
		
	});
