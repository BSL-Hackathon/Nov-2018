'use strict';
var appPublica = angular.module("appConsultaPublica");
/*******************************************************************************
 * Controlador Consulta Publica
 */
var otorgarLeyCode = 23;

appPublica.controller("consultaPublicaCtrl", function($scope, $rootScope, $window, $location, $sce, consultaPublicaServices) {
  function gpbn(name) {
    var match = RegExp('[?&]' + name + '=([^&]*)').exec(window.location.search);
    return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
  }
  var id = gpbn("id");
  if (id !== undefined) {
    consultaPublicaServices.getInfoByHash(id).then(function(data) {
      if (data !== undefined) {
        var documento = data.data.respuesta;
        if (data.data.codigo == 200) {
        	
            $scope.folio = documento.folio;
            $scope.urlPdf = documento.urlPdf;
	    	
        	if(documento.enppl == 1 && documento.ensii == 1){
				documento.crucesii = "SII & PPL";
			}else if(documento.enppl == 1 && documento.ensii == 0){
				documento.crucesii = "Solo PPL";
			}else if(documento.ensii == 1 && documento.enppl == 0){
				documento.crucesii = "Solo SII";
			}
        	
        	if(angular.isUndefined(!documento.documentodetalle.fechaautorizacion)){
        		var date = new Date(!documento.documentodetalle.fechaautorizacion);
            	documento.documentodetalle.fechaautorizacion = formatearFechaTimestamp(date);
        	}
        	
        	
        	date = new Date(documento.fechainsercionasp);
        	documento.fechainsercionasp = formatearFechaTimestamp(date);
        	
          $scope.documento = documento;
          
          // Acuse Recibo
          if(documento.documentodetalle.acuserecibo == 1) {
          	$scope.acuseRecibo = "Recibido";
          	$("#acuseRecibo").addClass("label-success");
          }else if(documento.documentodetalle.acuserecibo == -1) {
          	$scope.acuseRecibo = "Error";
          	$("#acuseRecibo").addClass("label-danger");
          }else{
          	$("#acuseRecibo").addClass("label-default");
              $scope.acuseRecibo = "No disponible";
          }	
          // acise recibo comercial
          
          if(documento.documentodetalle.acusearc == 1) {
          	$scope.acuseComercial = "Recibido";
              $("#acuseComercial").addClass("label-success");
          }else if(documento.documentodetalle.acusearc == 2) {
          	$scope.acuseComercial = "Rechazado";
              $("#acuseComercial").addClass("label-danger");
          }else{
          	$scope.acuseComercial = "No disponible";
              $("#acuseComercial").addClass("label-default");
          }
          
          //Ley
          if(documento.documentodetalle.acuseley == 1) {
          	$scope.reciboMercaderia = "Recibido";
              $("#reciboMercaderia").addClass("label-success");
          }else if(documento.documentodetalle.acuseley == -1) {
          	$scope.reciboMercaderia = "Error";
              $("#reciboMercaderia").addClass("label-danger");
          }else{
          	$scope.reciboMercaderia = "No recibido";
              $("#reciboMercaderia").addClass("label-default");
          }
          
          var evento = {};
          $scope.evento = evento;
          switch(documento.documentodetalle.acusewsreclamacion){
  			case 0: evento.class_ = "label-pend"; "N/D"; evento.glosa = "No disponible";  break;
  			case 1: evento.class_ = "label-rec"; evento.glosa = "RCD"; break;
  			case 2: evento.class_ = "label-acep"; evento.glosa = "ERM"; break;
  			case 3: evento.class_ = "label-rec"; evento.glosa = "RFP"; break;
  			case 4: evento.class_ = "label-rec"; evento.glosa = "RFT"; break;
  			
  			default: evento.class_ = "label-pend"; evento.glosa = "No disponible";

  		}
          
          
          var evento = {};
          $scope.evento = evento;
          switch(documento.documentodetalle.acusewsreclamacion){
  			case 0: evento.class_ = "label-pend"; "N/D"; evento.glosa = "No disponible";  break;
  			case 1: evento.class_ = "label-rec"; evento.glosa = "RCD"; break;
  			case 2: evento.class_ = "label-acep"; evento.glosa = "ERM"; break;
  			case 3: evento.class_ = "label-rec"; evento.glosa = "RFP"; break;
  			case 4: evento.class_ = "label-rec"; evento.glosa = "RFT"; break;
  			
  			default: evento.class_ = "label-pend"; evento.glosa = "No disponible";

  		} 
          
          var date = null;
          angular.forEach(documento.docreclog,function(item) {
        	  
              	//date = new Date(item.drlinsdate.year,item.drlinsdate.month,item.drlinsdate.dayOfMonth,
              		//	item.drlinsdate.hourOfDay,item.drlinsdate.minute,item.drlinsdate.second,0);
        	  	date = new Date(item.drlinsdatets);

              	item.drlinsdate = formatearFechaTimestamp(date);
        	  
        	
          });        
          $scope.observaciones = documento.docreclog;
          
        }
      }

    });
  }

  function formatearFechaTimestamp(date) {
    var toFormat = moment(date);
    return toFormat.format('dd/MM/YYYY hh:mm:ss A');
  }
  $scope.trustSrc = function(src) {
    return $sce.trustAsResourceUrl(src);
  }
});