'use strict';
var app = angular.module("appPortal");
/*******************************************************************************
 * Controlador resumen comprador
 */
app.controller("resumenC_Ctrl", function($scope, $rootScope, $window, $location, servicesPortal, corporativo, sharedProp) {
	$scope.cargando = false;
	$scope.currentPage = 0;
	$scope.pageSize = 10;
	var json = {};

	json.currentPage = $scope.currentPage;
	json.pageSize = $scope.pageSize;
	json.action = "resumenC";
	json.listaObtener = "";
	json.filtros = {};
	
	
	$scope.multirut = corporativo.list.length > 1;
	$rootScope.$on('refrescar', function(event, args) {
		$scope.cargarDatos(json);
	});
	
	
	
	$scope.cargarDatos = function() {
		
		json.filtros.corporativo = corporativo.list;
	
		servicesPortal.getResumen(json).then(function(response) {
			var resumen = response.data.generalValues;
			$scope.cantTotalSii = resumen.rec_solosii_cant;
			$scope.montoTotalSii = resumen.rec_solosii_monto;
			
			$scope.cantTotalPpl = resumen.rec_soloppl_cant;
			$scope.montoTotalPpl = resumen.rec_soloppl_monto;
			
			$scope.cantTotalAmbos = resumen.rec_ambos_cant;
			$scope.montoTotalAmbos = resumen.rec_ambos_monto;
			
			$scope.cantReclamadas = resumen.rec_reclamados_cant;
			$scope.montoTotalReclamadas = resumen.rec_reclamados_monto;
			
			$scope.cantErm = resumen.rec_aceptados_cant;
			$scope.montoTotalErm = resumen.rec_aceptados_monto;
			
			
			new Chart(document.getElementById("chart1"),{
		         "type":"horizontalBar",
		         "data":{
		            "labels":["Recibidos","Reclamados","Otorgamiento"],
		            "datasets":[{"label":"Acuses con el SII","data":[resumen.rec_recibidos_cant,$scope.cantReclamadas,$scope.cantErm],
		            "fill":true,
		            "backgroundColor":["rgba(75, 192, 192,.5)","rgba(255, 99, 132,.5)","rgba(72, 162, 63,.5)"],
		            "borderColor":["rgb(75, 192, 192)","rgb(255, 99, 132)","rgb(72,162,63)"],
		            "borderWidth":2}]},
		         "options":{"scales":{"xAxes":[{"ticks":{"beginAtZero":true}}]}}});
		});
	}
	
	$scope.filtrar = function() {
		var filtros = {};
		var isFiltro = false;
	
		if($("#fecha_emision_desde").val() != "" && $("#fecha_emision_hasta").val() != ""){
			isFiltro = true;
			filtros['fechaEmisionDesde'] = $("#fecha_emision_desde").val();
			filtros['fechaEmisionHasta'] = $("#fecha_emision_hasta").val();
		}
		
		json.filtros = filtros;
		json.filtrado = isFiltro;
		isFiltro = undefined;
		$scope.currentPage = 1;
		json.currentPage = $scope.currentPage;
		$scope.cargarDatos(json);
	
	}
	
	$scope.goRedirect = function(tipo) {
		var filtros = {};
		var lista = [];
		if(tipo == "reclamacion" || tipo == "ley"){
			lista.push(tipo);
			filtros['acusesChile'] = lista;
		}else if(tipo == "solosii" || tipo == "soloppl" || tipo == "siippl"){
			lista.push(tipo);
			filtros['listaCuadratura'] = lista;
		}
		
		filtros.fromResumen = 1;
		json.filtros = filtros;
		json.filtrado = true;
			
		sharedProp.setJsonFiltrosGestion(filtros);
		$location.url('/gestionComprador');
	}
	
	
	$scope.clearFilter = function() {
		$scope.filtroFechaEmisionDesde = undefined;
		$scope.filtroFechaEmisionHasta = undefined;
		$scope.filtrar();
	}
	
	$scope.cargarDatos(json);

});

