'use strict';
var app = angular.module("appPortal");
/*******************************************************************************
 * Controlador resumen comprador
 */
app.controller("resumenP_Ctrl", function($scope, $rootScope, $window, $location, servicesPortal, sharedProp) {
	$scope.cargando = false;
	$scope.currentPage = 0;
	$scope.pageSize = 10;
	var json = {};

	json.currentPage = $scope.currentPage;
	json.pageSize = $scope.pageSize;
	json.action = "resumenP";
	json.listaObtener = "";
	json.filtros = {};
	
	$scope.cargarDatos = function() {
	
		servicesPortal.getResumen(json).then(function(response) {
			var resumen = response.data.generalValues.resumen.generalValues;
			$scope.cantTotalSii = resumen.rec_solosii_cant;
			$scope.montoTotalSii = resumen.rec_solosii_monto;
			
			$scope.cantTotalPpl = resumen.rec_soloppl_cant;
			$scope.montoTotalPpl = resumen.rec_soloppl_monto;
			
			$scope.cantTotalAmbos = resumen.rec_ambos_cant;
			$scope.montoTotalAmbos = resumen.rec_ambos_monto;
			
			$scope.cantReclamadas = resumen.rec_reclamados_cant;
			$scope.montoTotalReclamadas = resumen.rec_reclamados_monto;
			
			$scope.cantErm = resumen.rec_aceptados_cant;
			$scope.montoTotalErm = resumen.rec_aceptados_monto;
			
			$scope.listaNoticias = response.data.generalValues.noticias.t;
			$scope.totalNoticias = response.data.generalValues.noticias.totalRows;
			
			
			new Chart(document.getElementById("chart1"),{
		         "type":"horizontalBar",
		         "data":{
		            "labels":["Recibidos","Reclamados","Otorgamiento"],
		            "datasets":[{"label":"Acuses con el SII","data":[resumen.rec_recibidos_cant,$scope.cantReclamadas,$scope.cantErm],
		            "fill":true,
		            "backgroundColor":["rgba(75, 192, 192,.5)","rgba(255, 99, 132,.5)","rgba(72, 162, 63,.5)"],
		            "borderColor":["rgb(75, 192, 192)","rgb(255, 99, 132)","rgb(72,162,63)"],
		            "borderWidth":2}]},
		         "options":{"scales":{"xAxes":[{"ticks":{"beginAtZero":true}}]}}});
		});
	}
	
	$scope.filtrar = function() {
		var filtros = {};
		var isFiltro = false;
	
		if($("#fecha_emision_desde").val() != "" && $("#fecha_emision_hasta").val() != ""){
			isFiltro = true;
			filtros['fechaEmisionDesde'] = $("#fecha_emision_desde").val();
			filtros['fechaEmisionHasta'] = $("#fecha_emision_hasta").val();
		}
		
		json.filtros = filtros;
		json.filtrado = isFiltro;
		isFiltro = undefined;
		$scope.currentPage = 1;
		json.currentPage = $scope.currentPage;
		$scope.cargarDatos(json);
	
	}
	
	
	$scope.clearFilter = function() {
		$scope.filtroFechaEmisionDesde = undefined;
		$scope.filtroFechaEmisionHasta = undefined;
		$scope.filtrar();
	}
	$scope.changeItemsToSee = function(e) {
		$('#itemsToSee').children('a').each(function() {
			if ($(this).hasClass('active')) {
				$(this).removeClass("active");
				return;
			}
		});
		$(e.currentTarget).addClass("active");
		$scope.pageSize = $(e.currentTarget).text();
		json.pageSize = $scope.pageSize;
		json.offSet = 0;
		$scope.cargarDatos(json);
	};
	
	
	$scope.goRedirect = function(tipo) {
		var filtros = {};
		var lista = [];
		if(tipo == "reclamacion" || tipo == "ley"){
			lista.push(tipo);
			filtros['acusesChile'] = lista;
		}else if(tipo == "solosii" || tipo == "soloppl" || tipo == "siippl"){
			lista.push(tipo);
			filtros['listaCuadratura'] = lista;
		}
		filtros.fromResumen = 1;
		json.filtros = filtros;
		json.filtrado = true;
			
		sharedProp.setJsonFiltrosGestion(filtros);
		$location.url('/gestionProveedor');
	}
	
	$scope.detNoticia = function(not) {
		
		json.action = "getNoticia";
		json.noticia = not;
		
		servicesPortal.getNoticia(json).then(function(response) {
			
			var noticiaDet = response.data.generalValues;	
			$scope.idnoticia = noticiaDet.noticia.idnoticia;
			$scope.txtTituloNot = noticiaDet.noticia.titulonot;
			$scope.txtContenidoNot = noticiaDet.noticia.textonot;
			$scope.fecNoticia = noticiaDet.noticia.fechatransaccion;

		});
	};
	
	$scope.cargarDatos(json);

});

