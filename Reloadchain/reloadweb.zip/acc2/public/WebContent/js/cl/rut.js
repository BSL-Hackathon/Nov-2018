/**
 * @author Cristian Rosas
 * @version 1.0.0, 2010
 *
 * Este script fue descargado de:
 * http://www.cristianrosas.cl/web/rut.html
 *
 * PROT�TIPOS:
 * m�todo String.lpad(int pSize, char pCharPad)
 * m�todo String.trim()
 *
 */

/**
 * Elimina los blancos al inicio y fin del un String
 */
String.prototype.trim = function() {
	return this.replace(/^\s*/, "").replace(/\s*$/, "");
} //String.trim


/**
 * Elimina los caracteres de formateo y los 0 a la izquierda.
 * @param String pNum Strin formateado.
 * @return String de n�mero desformateado.
 */
function quitarFormato(pRut) {
	if (pRut == null) return '';
	return String(pRut).toUpperCase().replace(/[^0-9K]/g, "").replace(/^0+/, "");
} //quitarFormato

/**
 * Elimina los caracteres de formateo.
 * @param String pNum Strin formateado.
 * @return String de n�mero desformateado.
 */
function quitarFormatoRut(pRut) {
	if (pRut == null) return '';
	var rut1 = String(pRut).toUpperCase().replace(/[^0-9K]/g, "");
	var rut2 = String(rut1).toUpperCase().replace(/[^0]/g, "");
	if (rut1 != '' && rut1 == rut2) {
		return '0';
	}
	return rut1;
}

function formatearRut(pRut) {
	var numero = quitarFormatoRut(pRut);
	if (numero == '0') return '00.000.000-0';
	if (numero.length < 2)  {
		return numero;
	}
	var base = numero.substring(0, numero.length - 1);
	var digito = numero.substring(numero.length - 1);
	var rut = formatoMiles(base)+'-'+digito;
	
	return rut;
} //formatearRut

function formatoMiles(str) {
	var num = '';
	
	if (!isNaN(str)) {
		num = str.toString().split('').reverse().join('').replace(/(?=\d*\.?)(\d{3})/g,'$1.');
		num = num.split('').reverse().join('').replace(/^[\.]/,'');
	}
	return num;
}

/**
 * Calcula el digito verificador del rut
 */
function dvRut(strValue)
{
	var tmprut = quitarFormato(strValue);
    if (tmprut.length > 1)  {
		tmprut = tmprut.substring(0, tmprut.length - 1);
	}
	var sum = 1;
	for(var mul = 0; tmprut != 0; tmprut = Math.floor( tmprut / 10 ))
		sum = (sum + tmprut % 10 * ( 9 - mul++ % 6 ) ) % 11;
	return (sum ? sum - 1 : 'K');
} //dvRut


function isRut(pRut) {
	var numero = quitarFormato(pRut);
	
	var base = numero;
	if (numero.length > 1)  {
		base = numero.substring(0, numero.length - 1);
	}
	var digito = dvRut(numero);
	
	// Valida el digito verificador
	return (numero == "" + base + digito);

} //isRut
