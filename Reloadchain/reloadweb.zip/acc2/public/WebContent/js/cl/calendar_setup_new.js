
Calendar.setup = function (_1) {
	function param_default(_2, _3) {
		if (typeof _1[_2] == "undefined") {
			_1[_2] = _3;
		}
	}
	param_default("inputField", null);
	param_default("displayArea", null);
	param_default("button", null);
	param_default("eventName", "click");
	param_default("ifFormat", "%Y-%m-%d");
	param_default("daFormat", "%Y-%m-%d");
	param_default("singleClick", true);
	param_default("minDate", "1900-01-01");
	param_default("maxDate", "2050-12-31");
	param_default("range", [_1["minDate"].substring(0, 4), _1["maxDate"].substring(0, 4)]);
	param_default("disableFunc", defaultdisableFunc);
	param_default("dateStatusFunc", _1["disableFunc"]);
	param_default("dateText", null);
	param_default("firstDay", null);
	param_default("align", "bl");
	param_default("weekNumbers", false);
	param_default("flat", null);
	param_default("flatCallback", null);
	param_default("onSelect", null);
	param_default("onClose", null);
	param_default("onUpdate", null);
	param_default("date", null);
	param_default("showsTime", false);
	param_default("timeFormat", "24");
	param_default("electric", false);
	param_default("step", 2);
	param_default("position", null);
	param_default("showOthers", false);
	param_default("multiple", null);
	param_default("cache", false);
	param_default("stickyDate", true);
	param_default("id", 0);
	param_default("dateFunc", null);
	param_default("yearButtons", true);
	param_default("todayButton", false);
	var _4 = ["inputField", "displayArea", "button"];
	for (var i in _4) {
		if (typeof _1[_4[i]] == "string") {
			_1[_4[i]] = document.getElementById(_1[_4[i]]);
		}
	}
	if (!(_1.flat || _1.multiple || _1.inputField || _1.displayArea || _1.button)) {
		alert("Calendar.setup:\n  Nothing to setup (no fields found).  Please check your code");
		return false;
	}
	function defaultdisableFunc(_6) {
		if (typeof _1.minDate != "undefined" && typeof _1.maxDate != "undefined") {
			var _7 = Date.parseDate(_1.minDate, _1.daFormat);
			var _8 = Date.parseDate(_1.maxDate, _1.daFormat);
			_8.setHours(23);
			_8.setMinutes(59);
			_8.setSeconds(59);
			if (_6 < _7 || _6 > _8) {
				return true;
			}
		}
		return false;
	}
	function onSelect(_9) {
		var p = _9.params;
		var _b = (_9.dateClicked || p.electric);
		if (_b && p.stickyDate) {
			p.date = _9.date;
		}
		if (_b && p.inputField) {
			p.inputField.value = _9.date.print(p.ifFormat);
			if (typeof p.inputField.onchange == "function") {
				p.inputField.onchange();
			}
		}
		if (_b && p.displayArea) {
			p.displayArea.innerHTML = _9.date.print(p.daFormat);
		}
		if (_b && typeof p.onUpdate == "function") {
			p.onUpdate(_9);
		}
		if (_b && p.flat) {
			if (typeof p.flatCallback == "function") {
				p.flatCallback(_9);
			}
		}
		if (_b && p.singleClick && _9.dateClicked) {
			_9.callCloseHandler();
		}
	}
	if (_1.flat != null) {
		if (typeof _1.flat == "string") {
			_1.flat = document.getElementById(_1.flat);
		}
		if (!_1.flat) {
			alert("Calendar.setup:\n  Flat specified but can't find parent.");
			return false;
		}
		var _c = new Calendar(_1.firstDay, _1.date, _1.onSelect || onSelect);
		_c.showsOtherMonths = _1.showOthers;
		_c.showsTime = _1.showsTime;
		_c.time24 = (_1.timeFormat == "24");
		_c.params = _1;
		_c.weekNumbers = _1.weekNumbers;
		_c.yearButtons = _1.yearButtons;
		_c.todayButton = _1.todayButton;
		_c.setRange(_1.range[0], _1.range[1]);
		_c.setDateStatusHandler(_1.dateStatusFunc);
		_c.getDateText = _1.dateText;
		if (_1.ifFormat) {
			_c.setDateFormat(_1.ifFormat);
		}
		if (_1.inputField && typeof _1.inputField.value == "string") {
			_c.parseDate(_1.inputField.value);
		}
		_c.create(_1.flat);
		_c.show();
		return false;
	}
	var _d = _1.button || _1.displayArea || _1.inputField;
	_d["on" + _1.eventName] = function () {
		var _e = _1.inputField || _1.displayArea;
		var _f = _1.inputField ? _1.ifFormat : _1.daFormat;
		var _10 = false;
		var cal = window.calendar;
		if (_e) {
			_1.date = Date.parseDate(_e.value || _e.innerHTML, _f);
		}
		if (_1.dateFunc) {
			_1.date = _1.dateFunc();
		}
		if (_1.disableFunc && _1.disableFunc(_1.date)) {
			_1.date = null;
		}
		if (!(cal && _1.cache)) {
			window.calendar = cal = new Calendar(_1.firstDay, _1.date, _1.onSelect || onSelect, _1.onClose || function (cal) {
				cal.hide();
			});
			cal.showsTime = _1.showsTime;
			cal.time24 = (_1.timeFormat == "24");
			cal.weekNumbers = _1.weekNumbers;
			_10 = true;
		} else {
			if (_1.date) {
				cal.setDate(_1.date);
			}
			cal.hide();
		}
		if (_1.multiple) {
			cal.multiple = {};
			for (var i = _1.multiple.length; --i >= 0; ) {
				var d = _1.multiple[i];
				var ds = d.print("%Y%m%d");
				cal.multiple[ds] = d;
			}
		}
		cal.showsOtherMonths = _1.showOthers;
		cal.yearStep = _1.step;
		cal.setRange(_1.range[0], _1.range[1]);
		cal.params = _1;
		cal.setDateStatusHandler(_1.dateStatusFunc);
		cal.getDateText = _1.dateText;
		cal.setDateFormat(_f);
		cal.yearButtons = _1.yearButtons;
		cal.todayButton = _1.todayButton;
		if (_10) {
			cal.create();
		}
		cal.refresh();
		if (!_1.position) {
			cal.showAtElement(_1.button || _1.displayArea || _1.inputField, _1.align);
		} else {
			cal.showAt(_1.position[0], _1.position[1]);
		}
		return false;
	};
	return _c;
};

