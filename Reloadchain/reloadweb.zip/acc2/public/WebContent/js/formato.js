'user strict'

var app = angular.module("paperless",[])
	.filter('rut', rutFormatter)
	.filter('rutPuntos', formatoRut);

/**
 * 
 */
function rutFormatter(){
	return function(rut) {
		if (rut === undefined) {
			return;
		}

		return "" + rut + "-" + dvRut(rut);
	}
}

function formatoRut(){
	return function(rut){
		
		if (rut === undefined) {
			return;
		}

		var sRut1 = rut+""+dvRut(rut);
		sRut1 = sRut1.toString(); //contador de para saber cuando insertar el . o la -
	    var nPos = 0; //Guarda el rut invertido con los puntos y el guión agregado
	    var sInvertido = ""; //Guarda el resultado final del rut como debe ser
	    var sRut = "";
	    for(var i = sRut1.toString().length - 1; i >= 0; i-- )
	    {
	        sInvertido += sRut1.charAt(i);
	        if (i == sRut1.length - 1 )
	            sInvertido += "-";
	        else if (nPos == 3)
	        {
	            sInvertido += ".";
	            nPos = 0;
	        }
	        nPos++;
	    }
	    for(var j = sInvertido.toString().length - 1; j >= 0; j-- )
	    {
	        if (sInvertido.charAt(sInvertido.toString().length - 1) != ".")
	            sRut += sInvertido.charAt(j);
	        else if (j != sInvertido.toString().length - 1 )
	            sRut += sInvertido.charAt(j);
	    }
	    //Pasamos al campo el valor formateado
	    rut = sRut.toUpperCase();
	    return rut+"";
	}
	
}


/**
 * Elimina los caracteres de formateo.
 * @param String pNum Strin formateado.
 * @return String de n�mero desformateado.
 */
function quitarFormatoRut(pRut) {
	if (pRut == null) return '';
	var rut1 = String(pRut).toUpperCase().replace(/[^0-9K]/g, "");
	var rut2 = String(rut1).toUpperCase().replace(/[^0]/g, "");
	if (rut1 != '' && rut1 == rut2) {
		return '0';
	}
	return rut1;
}

/**
 * Calcula el digito verificador del rut
 */
function dvRut(rut) {
	var sum = 1;
	for(var mul = 0; rut != 0; rut = Math.floor( rut / 10 ))
		sum = (sum + rut % 10 * ( 9 - mul++ % 6 ) ) % 11;
	return (sum ? sum - 1 : 'K');
} //dvRut
