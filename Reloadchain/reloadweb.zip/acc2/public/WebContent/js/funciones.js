function validaRut(strValue){
    var objRegExp = /^\d{7,9}\-(\d|k|K)$/
    if( !objRegExp.test(strValue) ) return false;
    var tmpRut = strValue.split('-');
    return ( tmpRut[1].toUpperCase() == getDigito(tmpRut[0]) );
}

function getDigito(strValue) {
	var tmprut = strValue;
	var sum = 1;
	for(var mul = 0; tmprut != 0; tmprut = Math.floor( tmprut / 10 ))
		sum = (sum + tmprut % 10 * ( 9 - mul++ % 6 ) ) % 11;
	return (sum ? sum - 1 : 'K');
}

function Popwin(theUrl,winName,features,width,height) {
  var str = features + ",height=" + height + ",innerHeight=" + height;
  str += ",width=" + width + ",innerWidth=" + width;
  if (window.screen) {
    var sh = screen.availHeight - 30;
    var sw = screen.availWidth - 10;

    var txc = (sw - width) / 2;
    var tyc = (sh - height) / 2;

    str += ",left=" + txc + ",screenX=" + txc;
    str += ",top=" + tyc + ",screenY=" + tyc;
  }
  return window.open(theUrl,winName,str);
}

function volver(url) {
	var oForm = document.frmVolver;
	//oForm.action = url;
	//oForm.submit();
	document.location=url;
}	

function irA(pagina) {
	document.frmIrA.action = pagina;
	document.frmIrA.submit();
}

function pagina(p) {
	var oForm = document.frmPaginacion;
	oForm.elements['.p'].value = p;
	oForm.submit();
}

function paginacion(p) {
	var oForm = document.frmPaginacion;
	oForm.elements['.p'].value = 1;
	oForm.elements['.pl'].value = p;
	oForm.submit();
}

function orden(s) {
	var oForm = document.frmPaginacion;
	if (oForm.elements['.s'].value != s) {
		oForm.elements['.o'].value = 'false';
	}
	else {
		oForm.elements['.o'].value = (oForm.elements['.o'].value == 'true' ? 'false' : 'true');
	}
	oForm.elements['.s'].value = s;
	oForm.submit();
}

function validaChk(oForm, sName) {
	len = oForm.elements.length;
    for(var i=0; i<len; i++) {
  	  if (oForm.elements[i].name==sName) {
        if (oForm.elements[i].checked) {
        	return true;
        }
  	  }
    }
		
	return false;
}

function eliminar(msgsel, msgconf) {
	var oForm = document.frmLista;
	
	if (validaChk(oForm, 'checkId') == false) {
	  	alert(msgsel);
	}  
	else { 
		if ( confirm(msgconf) == 1 ) { 
			oForm.elements['.ac'].value= 'eliminar';
			oForm.submit();
		}
	}
}

function seleccionarTodo(sName, bCheck) {
    var oForm = document.frmLista;
  	len = oForm.elements.length;
  	for (var i=0; i<len; i++) {
  		if (oForm.elements[i].name==sName) {
  			oForm.elements[i].checked = bCheck;
  		}
  	}
}

function deSeleccionarTodo(sName, sGlobal, bCheck) {
	var oForm = document.frmLista;
	if (!bCheck) {
		document.getElementById(sGlobal).checked = bCheck;
	}
	else {
		len = oForm.elements.length;
		for (var i=0; i<len; i++) {
			if (oForm.elements[i].name == sName) {
				if (!oForm.elements[i].checked) {
					document.getElementById(sGlobal).checked = !bCheck;
					return;
				}
			}
		}
		document.getElementById(sGlobal).checked = bCheck;
	}
}

function cambiarEstado(id, est) {
	var oForm = document.frmLista;
	oForm.elements['id'].value= id;
	oForm.elements['estado'].value = est;
	oForm.elements['.ac'].value = 'estado';
	oForm.submit();
}
