(function() {
	'use strict';
	//
	var app = angular.module("appReclamaciones");
	app.filter('dte_tipo_label', dteTipo);

	//
	var app = angular.module("appConsultaPublica");
	app.filter('dte_tipo_label', dteTipo);

	/**
	 * 
	 * @returns
	 */
	function dteTipo(){
		return function (input) {
			switch (input) {
			case 33:
				return 'FE';
			case 34:
				return 'FEE';
			case 43:
				return 'LFE';
			case 46:
				return 'FCE';
			case 52:
				return 'GD';
			case 55:
			case 56:
				return 'ND';
			case 60:
			case 61:
				return 'NC';
			default:
				return undefined;
			}
		}
	}
})();
