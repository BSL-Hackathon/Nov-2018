(function() {
	'use strict';
	//
	var app = angular.module("appReclamaciones");
	app.filter('reclamacion_tipo', reclamacionTipo);

	//
	var app = angular.module("appConsultaPublica");
	app.filter('reclamacion_tipo', reclamacionTipo);

	/**
	 * 
	 * @returns
	 */
	function reclamacionTipo() {
		return function(input) {
			switch (input) {
			case 0:
				return 'ACD';
			case 1:
				return 'RCD';
			case 2:
				return 'ERM';
			case 3:
				return 'RFP';
			case 4:
				return 'RFT';
			case 5:
				return 'PAG';
			default:
				return undefined;
			}
		}
	}
})();
