(function() {
	'use strict';
	//
	var app = angular.module("appReclamaciones");
	app.filter('canal', canal);

	//
	var app = angular.module("appConsultaPublica");
	app.filter('canal', canal);

	/**
	 * 
	 * @returns
	 */
	function canal() {
		return function(input) {
			switch (input) {
			case 1:
				return "Manual";
			case 2:
				return "Automático";
			case 3:
				return "Por tiempo";
			case 4:
				return "DTE Recovery";
			case 5:
				return "Portal SII";
			case 6:
				return "Pago al contado";
			case 7:
				return "WebService";
			default:
				return undefined;
			}
		}
	}
})();
