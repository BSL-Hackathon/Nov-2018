(function() {
	'use strict';
	//
	var app = angular.module("appPortal");
	app.filter('dte_tipo', dteTipo);

	//
	var app = angular.module("appConsultaPublica");
	app.filter('dte_tipo', dteTipo);

	/**
	 * 
	 * @returns
	 */
	function dteTipo(){
		return function (input) {
			switch (input) {
			case 33:
				return 'Factura Electrónica';
			case 34:
				return 'Factura Exenta Electrónica';
			case 43:
				return 'Liquidación-Factura Electrónica';
			case 46:
				return 'Factura de Compra Electrónica';				
			case 52:
				return 'Guía de Despacho';
			case 55:
				return 'Nota de Débito';				
			case 56:
				return 'Nota de Débito Electrónica';				
			case 60:
				return 'Nota de Crédito';				
			case 61:
				return 'Nota de Crédito Electrónica';				
			default:
				return undefined;
			}
		}
	}
})();
