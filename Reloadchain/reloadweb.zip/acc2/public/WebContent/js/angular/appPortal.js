var app = angular.module("appPortal", [ 'ngRoute', 'paperless', 'bw.paging', 'ngIdle', 'xeditable', 'ngSanitize','ngMessages']);

app
		.config([
				'$compileProvider',
				'$routeProvider',
				'$httpProvider',
				'TitleProvider',
				function($compileProvider, $routeProvider, $httpProvider, TitleProvider) {
					TitleProvider.enabled(false);

					$compileProvider
							.aHrefSanitizationWhitelist(/^\s*(https?|http?|javascript|ftp|mailto|file):/);

					$routeProvider
							.when(
								'/resumenComprador',
								{
									templateUrl : '/PortalProveedores/contenido/compradores/resumen.html',
									controller : 'resumenC_Ctrl'
								})
							.when(
								'/resumenProveedor',
								{
									templateUrl : '/PortalProveedores/contenido/proveedores/resumen.html',
									controller : 'resumenP_Ctrl'
								})
							.when(
								'/gestionComprador',
								{
									templateUrl : '/PortalProveedores/contenido/compradores/gestion-documental.jsp',
									controller : 'gestionC_Ctrl'
								})
							.when(
								'/gestionCompradorDetalle',
								{
									templateUrl : '/PortalProveedores/contenido/compradores/gestion-documental-detalle.html',
									controller : 'gestionC_DetalleCtrl'
								})
							.when(
								'/gestionProveedor',
								{
									templateUrl : '/PortalProveedores/contenido/proveedores/gestion-documental.jsp',
									controller : 'gestionP_Ctrl'
								})
							.when(
								'/gestionProveedorDetalle',
								{
									templateUrl : '/PortalProveedores/contenido/proveedores/gestion-documental-detalle.html',
									controller : 'gestionP_DetalleCtrl'
								})
							.when(
								'/misDatosComprador', 
								{
									templateUrl: '/PortalProveedores/contenido/compradores/mis-datos.html',
									controller: 'misDatosC_Ctrl'
								})
							.when(
								'/misDatosProveedor', 
								{
									templateUrl: '/PortalProveedores/contenido/proveedores/mis-datos.html',
									controller: 'misDatosP_Ctrl'
								})
							.when(
								'/proveedoresComprador',
								{
									templateUrl : '/PortalProveedores/contenido/compradores/adm-proveedores.jsp',
									controller : 'proveedoresC_Ctrl'
								})
							.when(
								'/proveedoresProveedor',
								{
									templateUrl : '/PortalProveedores/contenido/proveedores/adm-proveedores.jsp',
									controller : 'proveedoresP_Ctrl'
								})
							.when(
								'/usuariosComprador',
								{
									templateUrl : '/PortalProveedores/contenido/compradores/adm-usuarios.html',
									controller : 'usuarioC_Ctrl'
								})
							.when(
								'/usuariosProveedor',
								{
									templateUrl : '/PortalProveedores/contenido/proveedores/adm-usuarios.html',
									controller : 'usuarioP_Ctrl'
								})
							.when(
								'/listaContactos',
								{
									templateUrl : '/PortalProveedores/contenido/proveedores/adm-contactos.html',
									controller : 'contactosP_Ctrl'
								})
							.when(
								'/administraNoticias',
								{
									templateUrl : '/PortalProveedores/contenido/compradores/adm-noticias.jsp',
									controller : 'noticiasC_Ctrl'
								})
							.when(
								'/sin-permisos',
								{
									templateUrl : '/reclamacion/contenido/error/sin-permisos.html'
								}).
							when(
									'/error',
									{
										templateUrl : '/PortalProveedores/contenido/error/error.html'
									});;
					

					// INTERCEPTOR
					$httpProvider.interceptors
							.push(function($window) {
								return {
									responseError : function(response) {
										console.info('responseError', response);
										if (response.status == 401) {
											$window.location.href = '/PortalProveedores/login.jsp';
										}else if(response.status == 404){
											$window.location.href = '/PortalProveedores/contenido/error/error.html';
										}

										return 0;
									}
								}
							});
					
				} ]);

app.directive('ngFileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.ngFileModel);
            var isMultiple = attrs.multiple;
            var modelSetter = model.assign;
            element.bind('change', function () {
                var values = [];
                angular.forEach(element[0].files, function (item) {
                    var value = {
                       // File Name 
                        name: item.name,
                        //File Size 
                        size: item.size,
                        //File URL to view 
                        url: URL.createObjectURL(item),
                        // File Input Value 
                        _file: item
                    };
                    values.push(value);
                });
                scope.$apply(function () {
                    if (isMultiple) {
                        modelSetter(scope, values);
                    } else {
                        modelSetter(scope, values[0]);
                    }
                });
            });
        }
    };
}]);

//				} ]);

app.run(function(Idle, editableOptions) {
	//
	Idle.watch();
	editableOptions.theme = 'bs3';
});

/**
 * 
 */
//var appPublic = angular.module("appConsultaPublica", [ "ngRoute", "bw.paging",
//		"paperless", "ngSanitize" ]);
//
//appPublic
//		.config([
//				'$routeProvider',
//				'$compileProvider',
//				function($routeProvider, $compileProvider) {
//					$compileProvider
//							.aHrefSanitizationWhitelist(/^\s*(https?|http?|javascript|ftp|mailto|file):/);
//				} ]);
