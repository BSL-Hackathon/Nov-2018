/**
 * ----------------------------- URL PUBLICA MODULO
 * ---------------------------------
 */
var appPublic = angular.module("appConsultaPublica", [ "ngRoute", "bw.paging",
		"paperless", "ngSanitize" ]);

appPublic
		.config([
				'$routeProvider',
				'$compileProvider',
				function($routeProvider, $compileProvider) {
					$compileProvider
							.aHrefSanitizationWhitelist(/^\s*(https?|http?|javascript|ftp|mailto|file):/);
				} ]);