/**
 * ----------------------------- PASS MAILING MODULO
 * ---------------------------------
 */
var appPublic = angular.module("appPassMailing", [ "ngSanitize","ngRoute" ]);

appPublic
		.config([
				'$compileProvider',
				'$routeProvider',
				function($compileProvider,$routeProvider) {
					$compileProvider
							.aHrefSanitizationWhitelist(/^\s*(https?|http?|javascript|ftp|mailto|file):/);
					
					$routeProvider
					.when(
						'/crearClave',
						{
							templateUrl : '/PortalProveedores/contenido/passmailing/crear-clave.jsp',
							controller : 'passMailingCtrl'
						})
					.when(
						'/passMailing',
						{
							templateUrl : '/PortalProveedores/contenido/passmailing/passmailingbody.jsp',
							controller : 'passMailingCtrl'
						})
					.otherwise({
						redirectTo:	'/passMailing'
					});
				} ]);
