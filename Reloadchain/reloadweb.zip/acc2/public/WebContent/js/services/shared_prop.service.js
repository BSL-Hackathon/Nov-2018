(function() {
	'use strict';

	// /////////////////////////////////////////////////////////////////////////
	var app = angular.module("appPortal");

	// /////////////////////////////////////////////////////////////////////////
	app.service("sharedProp", function() {
		var jsonFiltrosGestion;

		return {
			getJsonFiltrosGestion : function() {
				var retorno = jsonFiltrosGestion;
				jsonFiltrosGestion = undefined;
				return retorno;
			},
			setJsonFiltrosGestion : function(value) {
				jsonFiltrosGestion = value;
			}
		};
	});
})();
