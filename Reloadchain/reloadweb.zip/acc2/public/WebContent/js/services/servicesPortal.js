'use strict';

	var app = angular.module("appPortal");
	var appPublica = angular.module("appConsultaPublica");
	var appPassMailing = angular.module("appPassMailing");

	
	
	app.service("servicesPortal", function($http){
		return {
			getDocumentosByCoId: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getHistoriaDocumentoById: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			exportarCsvGestion: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getResumen: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getMisDatos: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getListaProveedores: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			setStatusProveedor: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getProveedor: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			setProveedor: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getUsuarios: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			updateUsuario: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			actionUsuario: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getListaContactos: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			setContacto: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			addContacto: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			removeContacto: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getInfoByHash: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getListaNoticias: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			getNoticia: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			setNoticia: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			addNoticia: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			setStatusNoticia: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
		
			detNoticia: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},
			setUser: function(json){
				return $http({ 
					url: '/PortalProveedores/Portal',
					method: 'POST',
					data: {'data': json },
					headers: {'Content-Type':'application/json'} 
				});
			},

			
			
			
			
			
			
			
			
		}
	});


app.factory('corporativo', function(){
	var data = {};
	data.map = {};
	data.list = [];

	return data;
});

/*
app.service("configuracionService", function($http) {

	return {
		get: function() {
			return $http({
				url : '/reclamacion/Configuracion',
				method : 'GET',
				headers : {
					'Content-Type' : 'application/json'
				}
			});
		},
		save: function(items) {
			return $http({
				url : '/reclamacion/Configuracion',
				method : 'POST',
				headers : {
					'Content-Type' : 'application/json'
				},
				data : {
					'data' : items
				}
			});
		}
	};
});
*/
appPublica.service("consultaPublicaServices", function($http) {
	return {	
		getInfoByHash: function(items) {
			return $http({
				url : '/PortalProveedores/ConsultaPublica',
				method : 'POST',
				headers : {
					'Content-Type' : 'application/json'
				},
				data : {
					'data' : items
				}
			});
		},
	}
});


appPassMailing.service("servicesPassword", function($http) {
	return {	
		cambiarPassword: function(json){
			return $http({ 
				url: '/PortalProveedores/Portal',
				method: 'POST',
				data: {'data': json },
				headers: {'Content-Type':'application/json'} 
			});
		},
	}
});


	
