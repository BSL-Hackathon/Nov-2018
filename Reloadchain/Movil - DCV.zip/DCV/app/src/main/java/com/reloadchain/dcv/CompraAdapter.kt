package com.reloadchain.dcv

import android.widget.TextView
import android.support.v7.widget.CardView
import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.view.LayoutInflater
import android.widget.Toast
import android.content.DialogInterface
import android.support.v7.app.AlertDialog




class CompraAdapter(val dataset: ArrayList<Trx>) : RecyclerView.Adapter<CompraAdapter.CompraViewHolder>() {

    override fun onCreateViewHolder(view: ViewGroup, pos: Int): CompraViewHolder {
        val v = LayoutInflater.from(view.context).inflate(R.layout.row_comprar, view, false)
        return CompraViewHolder(v)

    }

    override fun getItemCount(): Int {
        return dataset.size
    }

    override fun onBindViewHolder(holder: CompraViewHolder, pos: Int) {
        holder.card.setOnClickListener {
            AlertDialog.Builder(it.context)
                .setTitle("Comprar")
                .setMessage("¿ Esta seguro que desea comprar ?")
                .setPositiveButton("SI") { _, _ -> Services().comprar()}
                .setNegativeButton("NO", null)
                .show()
        }
        holder.monto.text = dataset[pos].monto.toString()
        holder.titulo.text = dataset[pos].titulo
    }

    class CompraViewHolder internal constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {
        internal var card: CardView = itemView as CardView
        internal var titulo: TextView = itemView.findViewById(R.id.lblCompraTitulo)
        internal var monto: TextView = itemView.findViewById(R.id.lblCompraMonto)

    }

}
