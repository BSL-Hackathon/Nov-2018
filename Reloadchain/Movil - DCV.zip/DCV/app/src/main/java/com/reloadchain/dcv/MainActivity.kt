package com.reloadchain.dcv

import android.content.Intent
import android.support.design.widget.TabLayout
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.ViewPager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import okio.ByteString


class MainActivity : AppCompatActivity() {

    /**
     * The [android.support.v4.view.PagerAdapter] that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * [android.support.v4.app.FragmentStatePagerAdapter].
     */
    private var mSectionsPagerAdapter: SectionsPagerAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(toolbar)
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = SectionsPagerAdapter(supportFragmentManager)

        // Set up the ViewPager with the sections adapter.
        container.adapter = mSectionsPagerAdapter

        container.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabs))
        tabs.addOnTabSelectedListener(TabLayout.ViewPagerOnTabSelectedListener(container))


        val client = OkHttpClient()
        val request = Request.Builder().url("ws://172.20.10.12:3000").build()
        //val listener = EchoWebSocketListener()
        //val ws = client.newWebSocket(request,  listener)

    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main2, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId

        if (id == R.id.action_settings) {
            return true
        }

        return super.onOptionsItemSelected(item)
    }


    /**
     * A [FragmentPagerAdapter] that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    inner class SectionsPagerAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {

        override fun getItem(position: Int): Fragment {
//            Toast.makeText(this@MainActivity, "pos: $position", Toast.LENGTH_LONG).show()
            if (position == 0){
                return HomeFragment()
            }
            if (position == 1){
                return CompraFragment()
            }
            if (position == 2){
                return VentaFragment()
            }
            if (position == 3){
                return PagarFragment()
            }
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            return HomeFragment()
        }

        override fun getCount(): Int {
            // Show 3 total pages.
            return 4
        }
    }





    private inner class EchoWebSocketListener : WebSocketListener() {
        private val NORMAL_CLOSURE_STATUS = 10000

        override fun onOpen(webSocket: WebSocket, response: Response) {
            //webSocket.send("Hello, it's SSaurel !")
            //webSocket.send("What's up ?")
            //webSocket.send(ByteString.decodeHex("deadbeef"))
            //webSocket.close(NORMAL_CLOSURE_STATUS, "Goodbye !")
        }

        override fun onMessage(webSocket: WebSocket?, text: String?) {
            //if (text!!.contains("CrearRecetaEvent")){
            this@MainActivity.runOnUiThread {
                Toast.makeText(applicationContext,"Text rec : $text", Toast.LENGTH_LONG).show()
            }

                //webSocket!!.close(NORMAL_CLOSURE_STATUS, "Goodbye !")

            //}
        }

        override fun onMessage(webSocket: WebSocket?, bytes: ByteString) {
            this@MainActivity.runOnUiThread {
                Toast.makeText(this@MainActivity,"Receiving bytes : " + bytes.hex(), Toast.LENGTH_LONG).show()
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String?) {
            webSocket.close(NORMAL_CLOSURE_STATUS, null)
            this@MainActivity.runOnUiThread {
                Toast.makeText(applicationContext, "Closing : $code / $reason", Toast.LENGTH_LONG).show()
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            this@MainActivity.runOnUiThread {
                Toast.makeText(applicationContext, "Error : " + t.message, Toast.LENGTH_LONG).show()
            }
        }

    }
}
