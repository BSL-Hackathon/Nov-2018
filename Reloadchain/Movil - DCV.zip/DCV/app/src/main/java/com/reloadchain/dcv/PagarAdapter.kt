package com.reloadchain.dcv

import android.widget.TextView
import android.support.v7.widget.CardView
import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.view.LayoutInflater




class PagarAdapter(val dataset: ArrayList<Trx>) : RecyclerView.Adapter<PagarAdapter.CompraViewHolder>() {

    override fun onCreateViewHolder(view: ViewGroup, pos: Int): CompraViewHolder {
        val v = LayoutInflater.from(view.context).inflate(R.layout.row_comprar, view, false)
        return CompraViewHolder(v)

    }

    override fun getItemCount(): Int {
        return dataset.size
    }

    override fun onBindViewHolder(holder: CompraViewHolder, pos: Int) {
        holder.monto.text = dataset[pos].monto.toString()
        holder.titulo.text = dataset[pos].titulo
    }

    class CompraViewHolder internal constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {
        internal var card: CardView = itemView as CardView
        internal var titulo: TextView = itemView.findViewById(R.id.lblCompraTitulo)
        internal var monto: TextView = itemView.findViewById(R.id.lblCompraMonto)

    }

}
