package com.reloadchain.dcv

data class Trx(val titulo: String, val monto: Int, val estado: String)