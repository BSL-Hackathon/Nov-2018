package com.reloadchain.dcv

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.TextInputEditText
import com.github.kittinunf.fuel.httpGet
import kotlinx.android.synthetic.main.activity_login.*
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val txtRut = findViewById<TextInputEditText>(R.id.txtRut)
        btnEnter.setOnClickListener {

            (Services.URL_BUSCAR_POR_ID + txtRut.text.toString()).httpGet().responseString { request, response, result ->
                val (people, err) = result
                val data = String(response.data)
                val jsonObj = JSONObject(data)
                val datos = JSONObject(jsonObj.getString("datos"))
                Services.name = datos.getString("nombre") + " " + datos.getString("apellido")
                Services.id = txtRut.text.toString()
                Services.cantAcc = datos.getInt("cantAcc")
                val i = Intent(this@LoginActivity, MainActivity::class.java)
                startActivity(i)
            }
        }

    }
}
