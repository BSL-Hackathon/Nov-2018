package com.reloadchain.dcv


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.support.v7.widget.LinearLayoutManager





class DetalleActivity : AppCompatActivity() {

    lateinit var dataSet: ArrayList<Trx>
    lateinit var adapter: DetalleAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle)

        dataSet = ArrayList()
        dataSet.add(Trx("Empresa 1111",11110000,"OK"))
        dataSet.add(Trx("Empresa 2222",22220000,"OK"))
        dataSet.add(Trx("Empresa 3333",33330000,"OK"))

        adapter = DetalleAdapter(dataSet)

        val rec = findViewById<RecyclerView>(R.id.recCompra)
        rec.setHasFixedSize(true)
        rec.adapter = adapter
        val llm = LinearLayoutManager(this)
        rec.layoutManager = llm

    }


}
