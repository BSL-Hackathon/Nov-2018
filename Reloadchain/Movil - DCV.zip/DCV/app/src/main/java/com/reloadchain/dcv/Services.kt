package com.reloadchain.dcv

import android.app.Activity
import android.widget.Toast
import com.github.kittinunf.fuel.gson.responseObject
import com.github.kittinunf.fuel.httpGet
import org.json.JSONObject

class Services {

    companion object {
        lateinit var id: String
        lateinit var name: String
        var cantAcc: Int = 0




        val URL_BUSCAR_POR_ID = "http://172.20.10.12:3000/api/Participante/"
        val URL_POST_CREA = "http://172.20.10.12:3000/api/TrxCrea/"


    }







    fun comprar() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}