package com.reloadchain.dcv

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.github.kittinunf.fuel.httpPost
import com.google.zxing.integration.android.IntentIntegrator
import com.google.zxing.integration.android.IntentResult
import org.json.JSONObject
import java.lang.Exception
import java.util.*

//import com.budiyev.android.codescanner.AutoFocusMode
//import com.budiyev.android.codescanner.CodeScanner
//import com.budiyev.android.codescanner.CodeScannerView
//import com.budiyev.android.codescanner.DecodeCallback
//import com.budiyev.android.codescanner.ErrorCallback
//import com.budiyev.android.codescanner.ScanMode

class RegisterActivity : AppCompatActivity() {

//    private lateinit var codeScanner: CodeScanner

    private lateinit var qr: IntentIntegrator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val btn = findViewById<Button>(R.id.btnContinuar)
        qr = IntentIntegrator(this)
        qr.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES)
        qr.setBarcodeImageEnabled(false)

        btn.setOnClickListener {
            qr.initiateScan()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val res = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (res != null){
            if (res.contents == null){
                Toast.makeText(this,"Error", Toast.LENGTH_SHORT).show()
            }else{
                try {
                    val value = res.contents
                    Toast.makeText(this,value, Toast.LENGTH_SHORT).show()

                    //create(value)



                }catch(e: Exception){

                    Toast.makeText(this,"", Toast.LENGTH_SHORT).show()

                }
            }
        }else{

        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    fun create(id:String, cantAcc:Int, monto: Int){

        val uid = UUID.randomUUID().toString()
        var x = "{\"activoId\": \"$uid\", \"comprador\": \"resource:com.reload.dcv.Participante#$id\","
        x=x+"\"vendedor\": \"resource:com.reload.dcv.Participante#"+Services.id+"\","
        x= "$x\"cantAcc\": \"$monto\","
        x= "$x\"comentario\": \"\","
        x= "$x\"monto\": $cantAcc,"
        x= "$x\"okDCV\": false}"

        val map = HashMap<String, String>()
        map["activoId"] = uid
        map["comprador"] = "resource:com.reload.dcv.Participante#$id"
        map["vendedor"] = "resource:com.reload.dcv.Participante#"+Services.id


        val json = JSONObject(map)
//        //val post = URL_PUBLICAR.httpPost()
//        post.headers.put("Content-Type", "application/json")
//        post.body(json.toString()).response { request, response, result ->
//
//            if (response.statusCode == 200) {
//                Toast.makeText(applicationContext, "Ha publicado su receta", Toast.LENGTH_LONG).show()
//            }
//

            Services.URL_POST_CREA.httpPost()

    }
}

