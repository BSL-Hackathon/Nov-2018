package com.reloadchain.dcv

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.github.kittinunf.fuel.httpGet
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.journeyapps.barcodescanner.BarcodeEncoder
import org.json.JSONObject


class HomeFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {



        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        val lblNombre = view.findViewById<TextView>(R.id.lblNombre)
        val lblMonto = view.findViewById<TextView>(R.id.lblMonto)

        lblNombre.text = Services.name
        lblMonto.text = Services.cantAcc.toString()

        val multiFormatWriter = MultiFormatWriter()
        try {
            val bitMatrix = multiFormatWriter.encode("1", BarcodeFormat.QR_CODE, 500, 500)
            val barcodeEncoder = BarcodeEncoder()
            val bitmap = barcodeEncoder.createBitmap(bitMatrix)
            val imgQR = view.findViewById<ImageView>(R.id.imgQR)
            imgQR.setImageBitmap(bitmap)
            val fabAdd = view.findViewById<FloatingActionButton>(R.id.fabAdd)
            fabAdd.setOnClickListener {
                val i = Intent(activity, RegisterActivity::class.java)
                (activity as MainActivity).startActivity(i)
            }

        } catch (e: WriterException) {
            e.printStackTrace()
        }
        val btnDetalle = view.findViewById<Button>(R.id.btnDetalle)
        btnDetalle.setOnClickListener {
            val i = Intent(activity, DetalleActivity::class.java)
            (activity as MainActivity).startActivity(i)
        }

        return view
    }

}
