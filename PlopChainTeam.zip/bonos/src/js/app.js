App = {
  web3Provider: null,
  contracts: {},

  init: function() {
    return App.initWeb3();
  },

  initWeb3: function() {
    // Initialize web3 and set the provider to the testRPC.
    if (typeof web3 !== 'undefined') {
      App.web3Provider = web3.currentProvider;
      web3 = new Web3(web3.currentProvider);
    } else {
      // set the provider you want from Web3.providers
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
      web3 = new Web3(App.web3Provider);
    }

    return App.initContract();
  },

  initContract: function() {
    $.getJSON('InstrumentoFactory.json', function(data) {
      // Get the necessary contract artifact file and instantiate it with truffle-contract.
      var InstrumentoFactoryArtifact = data;
      App.contracts.InstrumentoFactory = TruffleContract(InstrumentoFactoryArtifact);
      // Set the provider for our contract.
      App.contracts.InstrumentoFactory.setProvider(App.web3Provider);

      // Use our contract to retieve and mark the adopted pets.
      return App.getAddressContracts();
    });

    return App.bindEventsOpciones();
  },

  bindEventsOpciones: function() {
    console.log('Bind' );
    $(document).on('click', '#B_registrar_Instrumento', App.handleRegistrarInstrumento);
    $(document).on('click', '#B_buscar_Instrumento', App.handleBuscarInstrumento);
    $(document).on('click', '#B_aceptar_Bono', App.handleAceptarBono);
    //$(document).on('click', '#B_generar_Bono', App.handleGenerarBono);


  },


  handleAceptarBono: function() {
    event.preventDefault();

    var N_hash_Instrumento = $('#N_hash_Instrumento').val();
    console.log('N_hash_Instrumento: ' + N_hash_Instrumento );

    //var tutorialTokenInstance;
    var InstrumentoFactoryInstance;

    web3.eth.getAccounts(function(error, accounts) {
      App.contracts.InstrumentoFactory.deployed().then(function(instance) {
      InstrumentoFactoryInstance = instance;
      console.log('paso 1 aceptar bono ');
      return  InstrumentoFactoryInstance.verificacionCFM(N_hash_Instrumento,1);

    }).then(function(result) {
      alert('Bono aceptado! ');
      //$('#T_rpta_RegistroUniversidad').text(result);
      $('#T_rpta_BonoAceptado').text('Instrumento aceptado...');
      }).catch(function(err) {
        alert('Error al registar estado Instrumento! ');
        console.log(err.message);
      });
    });
  },

  handleBuscarInstrumento: function() {
      event.preventDefault();
      var N_hash_Instrumento = $('#N_hash_Instrumento').val();
      console.log('N_hash_Instrumento ' + N_hash_Instrumento);

      var InstrumentoFactoryInstance;
      console.log('paso 1 search certificado');

      App.contracts.InstrumentoFactory.deployed().then(function(instance) {
      InstrumentoFactoryInstance = instance;

      //console.log(InstrumentoFactoryInstance);
      //Revisar los logs de transacciones
      return InstrumentoFactoryInstance.searchInstrumento(N_hash_Instrumento);
    }).then(function(result) {

        console.log('RESPUESTA....!!');
        console.log(result);
        var Tr_address_Emisor = result[0];
        var Tr_address_CMF   = result[1];
        var Tr_nombre_Emisor   = result[2];
        //var Tr_fecnacim_estudiante = result[3];
        var Tr_tipo_instrumento  = result[4];
        var Tr_tipo_unidad       = result[5];
        var Tr_cantidad          = result[6]['c'][0];

        $('#Tr_address_Emisor').val(Tr_address_Emisor);
        $('#Tr_address_CMF').val(Tr_address_CMF);
        $('#Tr_nombre_Emisor').val(Tr_nombre_Emisor);
        $('#Tr_tipo_instrumento').val(Tr_tipo_instrumento);
        $('#Tr_tipo_unidad').val(Tr_tipo_unidad);
        $('#Tr_cantidad').val(Tr_cantidad);

        //return App.getBalances();
      }).catch(function(err) {
        console.log(err.message);
      });
  },

  handleRegistrarInstrumento: function() {
    event.preventDefault();

    var T_address_cmf = $('#address_cmf').val();
    var T_address_user  = $('#address_user').val();
    var T_name_user  = $('#name-user').val();
    var T_tipo_instrumento = $('#tipo_instrumento').val();
    var T_tipo_unidad = $('#tipo_unidad').val();
    var T_bono_cantidad = $('#bono_cantidad').val();

    console.log('T_address_cmf ' + T_address_cmf +
               ' T_address_user ' + T_address_user +
               ' T_name_user ' + T_name_user +
               ' T_tipo_instrumento ' + T_tipo_instrumento +
               ' T_tipo_unidad ' + T_tipo_unidad +
               ' T_bono_cantidad ' + T_bono_cantidad);

    //var tutorialTokenInstance;
    var InstrumentoFactoryInstance;

    web3.eth.getAccounts(function(error, accounts) {
      App.contracts.InstrumentoFactory.deployed().then(function(instance) {
      InstrumentoFactoryInstance = instance;
      console.log('paso 1 registro Instrumento ');
      //var valhash = web3.utils.randomHex(32)

      return InstrumentoFactoryInstance.createInstrumento(T_address_cmf,
                                                          T_name_user,
                                                          T_tipo_instrumento,
                                                          T_tipo_unidad,
                                                          T_bono_cantidad );

    }).then(function(result) {

      console.log(result);

      for (var i = 0; i < result.logs.length; i++) {
        var log = result.logs[i];
        if (log.event == "NewInstrumento") {

           var T_tipoInstrumento = log.args["T_tipoInstrumento"];
           var T_tipoUnidad = log.args["T_tipoUnidad"];
           var T_cantidad = log.args["T_cantidad"];
           var Tvalor_hash_1 = log.args["_valhash"]['c'][0]
           var Tvalor_hash_2 = log.args["_valhash"]['c'][1]
           var Tvalor_hash = Tvalor_hash_1.toString() + Tvalor_hash_2.toString()
           var Tr_valHash = parseInt(Tvalor_hash);

           break;
        }
      }

      $('#Tr2_valHash').text(Tr_valHash);

      console.log(Tr_valHash);


      }).catch(function(err) {
        alert('Error al registar Instrumento! ');
        console.log(err.message);
        $('#Tr2_valHash').text('ERROR AL REGISTRAR Instrumento...');
      });
    });
  },

  handleTransfer4: function() {
    event.preventDefault();

    var TTDir_Universidad2 = $('#TTDir_Universidad2').val();
    var TTNombre_Universidad2 = $('#TTNombre_Universidad').val();

    console.log('TTDir_Universidad2 ' + TTDir_Universidad2 +
               ' TTNombre_Universidad2 ' + TTNombre_Universidad2 );

    //var tutorialTokenInstance;
    var InstrumentoFactoryInstance;

    web3.eth.getAccounts(function(error, accounts) {
      App.contracts.InstrumentoFactory.deployed().then(function(instance) {
      InstrumentoFactoryInstance = instance;
      console.log('paso 1 registro universidad ');
      //var valhash = web3.utils.randomHex(32)

      return  InstrumentoFactoryInstance.getUniversidad_p(TTDir_Universidad2);

    }).then(function(result) {
         if (result == ""){
           alert('Universidad No Registrada! ' );
         }else {
           alert('Universidad Registrada! ' + result);
           $('#TTBusqueda_Registro').text(result);
         }

      }).catch(function(err) {
        alert('Error al registar Certificado! ');
        console.log(err.message);
        $('#TTEstado_Registro').text('ERROR AL REGISTRAR UNIVERSIDAD...');
      });
    });
  },

  getAddressContracts: function(adopters, account) {
    console.log('Getting balances...');

    var InstrumentoFactoryInstance;

    web3.eth.getAccounts(function(error, accounts) {

    var account = accounts[0];
    console.log('obteniendo direccion cuenta 0 '+ account );

    App.contracts.InstrumentoFactory.deployed().then(function(instance) {
        InstrumentoFactoryInstance = instance;
        //return InstrumentoFactoryInstance.get_balance(account); //getBalances(account);
        //return InstrumentoFactoryInstance.get_balance(TTCtaAseguradoAddress); //getBalances(account);
        console.log('obteniendo direccion contrato 1' );
        //return InstrumentoFactoryInstance.getOwnerContrato();
        $('#address-user').text(account);
        return InstrumentoFactoryInstance.address;
      }).then(function(result_dir) {
        console.log('obteniendo direccion contrato 2' + result_dir);
        console.log('obteniendo account ' + account);
        $('#address_user').text(account);

        $('#TTDir_Contrato').text(result_dir);

      }).catch(function(err) {
        console.log(err.message);
      });

    });



  }

};

$(function() {
  $(window).load(function() {
    App.init();
  });
});
