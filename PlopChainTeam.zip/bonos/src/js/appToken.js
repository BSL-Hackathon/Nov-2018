App2 = {
  web3Provider: null,
  contracts: {},

  init: function() {
    return App2.initWeb3();
  },

  initWeb3: function() {
    // Initialize web3 and set the provider to the testRPC.
    if (typeof web3 !== 'undefined') {
      App2.web3Provider = web3.currentProvider;
      web3 = new Web3(web3.currentProvider);
    } else {
      // set the provider you want from Web3.providers
      App2.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
      web3 = new Web3(App2.web3Provider);
    }

    return App2.initContract();
  },

  initContract: function() {
    $.getJSON('TokenERC20.json', function(data) {
      // Get the necessary contract artifact file and instantiate it with truffle-contract.
      var TokenERC20Artifact = data;
      App2.contracts.TokenERC20 = TruffleContract(TokenERC20Artifact);
      // Set the provider for our contract.
      App2.contracts.TokenERC20.setProvider(App2.web3Provider);

      // Use our contract to retieve and mark the adopted pets.
      return App2.getAddressContracts();
    });



    return App2.bindEventsOpciones();
  },

  bindEventsOpciones: function() {
    console.log('Bind' );
    $(document).on('click', '#B_generar_Bono', App2.handleGenerarBono);

  },


  handleGenerarBono: function() {
    event.preventDefault();

    var Tr_address_Emisor2 = $('#Tr_address_Emisor').val();
    var Tr_cantidad2 = $('#Tr_cantidad').val();

    console.log('Tr_address_Emisor2 ' + Tr_address_Emisor2 + ' Tr_cantidad2 ' + Tr_cantidad2);

    var TokenERC20Instance;

    web3.eth.getAccounts(function(error, accounts) {
      console.log('paso 1 generar bono ');
      App2.contracts.TokenERC20.deployed().then(function(instance) {
      console.log('paso 2 generar bono ');
      TokenERC20Instance = instance;
      console.log('paso 3 generar bono ');

      return  TokenERC20Instance.transfer(Tr_address_Emisor2,Tr_cantidad2);

    }).then(function(result) {

        $('#T_rpta_BonoAceptado').text("Bono Token transferido !!!!");

    }).catch(function(err) {

        $('#T_rpta_BonoAceptado').text("Error al transferir Bono Token!!!!");
        console.log(err.message);
      });
    });
  },

  getAddressContracts: function(adopters, account) {
    console.log('Getting balances...');

    var TokenERC20Instance;

    web3.eth.getAccounts(function(error, accounts) {

    var account = accounts[0];
    console.log('obteniendo direccion cuenta 0 '+ account );

    App2.contracts.TokenERC20.deployed().then(function(instance) {
        TokenERC20Instance = instance;
        //return TokenERC20Instance.get_balance(account); //getBalances(account);
        //return TokenERC20Instance.get_balance(TTCtaAseguradoAddress); //getBalances(account);
        console.log('obteniendo direccion contrato 1' );
        //return TokenERC20Instance.getOwnerContrato();
        $('#address-user').text(account);
        return TokenERC20Instance.address;
      }).then(function(result_dir) {
        console.log('obteniendo direccion contrato 2' + result_dir);
        console.log('obteniendo account ' + account);
        $('#address_user').text(account);

        $('#TTDir_Contrato').text(result_dir);

      }).catch(function(err) {
        console.log(err.message);
      });

    });



  }

};

$(function() {
  $(window).load(function() {
    App2.init();
  });
});
