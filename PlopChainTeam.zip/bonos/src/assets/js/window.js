function change(address) {
	var direccion = "file:///home/christian/HTML5/BCS_HACKATHON/html5up-astral/index.html#" + address;
	window.location = direccion;
}