function myFunction() {
	var x = document.createElement("INPUT");
	x.setAttribute("type", "file");
	document.body.appendChild(x);
}