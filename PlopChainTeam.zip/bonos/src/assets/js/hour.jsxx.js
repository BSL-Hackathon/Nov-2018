var d = new Date();
var formato = d.getDate().toString() + "/" + (d.getMonth()+1).toString() + "/" + d.getFullYear().toString();
document.getElementById("my-date-actually").placeholder = formato;