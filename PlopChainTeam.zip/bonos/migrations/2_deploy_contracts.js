
var TokenERC20 = artifacts.require("./TokenERC20.sol");
var arg1 = 1000000;
var arg2 = "Bono Token";
var arg3 = "BT"

module.exports = function(deployer) {
     deployer.deploy(TokenERC20,arg1,arg2,arg3);
     //deployer.deploy(TokenERC20); esto se ejecuta a priori, se ejecut desde remix llamando al constructor con prametros: 1000000,"Bono-Token","BT"

};
