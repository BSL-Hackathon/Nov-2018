var InstrumentoFactory = artifacts.require("./InstrumentoFactory.sol");

module.exports = function(deployer) {
     deployer.deploy(InstrumentoFactory);
};
