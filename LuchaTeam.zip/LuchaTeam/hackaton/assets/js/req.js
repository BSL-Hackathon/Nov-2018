var buff_t = [];
var buff_h = []; 

var grafo_t = Morris.Area({
	element: 'grafo_t',
	pointSize: 0, 
	data: buff_t,
	xkey: 'y',
	ykeys: ['t'],
	hideHover: 'auto',
	lineColors: ['#B11623'],
	linewidth: '3px',
	smooth: true,
	labels: ['Temperatura'],
	axes: false,
	grid: false,
	hideHover: false,
	dateFormat: function(epoch) {
				var date = new Date(parseFloat(epoch + '000'));
				fecha = addZero(date.getDate()) + "." +
				addZero((date.getMonth() + 1)) + "." +
				date.getFullYear() + " " +
				addZero(date.getHours()) + ":" +
				addZero(date.getMinutes()) + ":" +
				addZero(date.getSeconds());
				return fecha; 
	},
	postUnits: '°C'
});

var grafo_h = Morris.Area({
	element: 'grafo_h',
	pointSize: 0, 
	data: buff_h,
	xkey: 'y',
	ykeys: ['h'],
	hideHover: 'auto',
	lineColors: ['#3B8183'],
	linewidth: '3px',
	smooth: true,
	labels: ['Humedad'],
	axes: false,
	grid: false,
	hideHover: false,
	dateFormat: function(epoch) {
				var date = new Date(parseFloat(epoch + '000'));
				fecha = addZero(date.getDate()) + "." +
				addZero((date.getMonth() + 1)) + "." +
				date.getFullYear() + " " +
				addZero(date.getHours()) + ":" +
				addZero(date.getMinutes()) + ":" +
				addZero(date.getSeconds());
				return fecha; 
	},
	postUnits: '%	'
});




function hex2a(hex) {
	var str = '';
	for (var i = 0; i < hex.length; i += 2) str += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
	return str;
}

function addZero(i) {
	if (i < 10) {
		i = "0" + i;
	}
	return i;
}

function hexToBytes(hex) {
	for (var bytes = [], c = 0; c < hex.length; c += 2)
	bytes.push(parseInt(hex.substr(c, 2), 16));
	return bytes;
}



function unpackLong(long) {

	return long = new Uint32Array((new Uint8Array(hexToBytes(long))).buffer)[0]; 
}

function unpackShort(short) {
	return short = new Uint8Array((new Uint8Array(hexToBytes(short))).buffer)[0];
}
