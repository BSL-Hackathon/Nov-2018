<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!--CSS -->
  <?php
  $this->load->view("comun/css");
  ?>

  <title>Buscar Registro</title>
</head>
<body >
  <?php
  $this->load->view("comun/menu");
  ?>
  <div class="container sombra" style="margin-top: 10px;">
    <div class="row">
      <div class="col-md-12 text-left">
        <?php
        if ($this->session->userdata('mensaje')!=null) {
         ?> 
         <div class="alert alert-success" role="alert">
          <?=$this->session->userdata('mensaje')?>
        </div>
        <?php
        $this->session->unset_userdata('mensaje');
      }
      ?>
      <br>
      <h1>Ingresar registro</h1>
    </div>
  </div>


  <br/>

  <div class="row">
    
    <label class="col-lg-3">Rut Empresa a buscar:</label>
    <input class="form-control col-lg-4" autocomplete="off" placeholder="1-9">
    
  </div>

  <div class="row">
    
    <label class="col-lg-3">Llave privada:</label>
    <input class="form-control col-lg-4" autocomplete="off" placeholder="PRIV KEY">
    
  </div>
  <div>
    

    <br/>

  </div>
  <div class="form-group">

    <button type="button" onclick="getBlockchain()" class="btn btn-primary">Buscar data</button>
  </div>

  <h1>Datos De Empresa</h1>
  <div id="datosEmpresa">

  </div></br>
  <h1>Datos Representante</h1>
  <div id="datosRepresentante_legal">

  </div></br>
  <h1>Datos Socios</h1>
  <div id="datosSocios">

  </div>

</div>
<!-- Optional JavaScript -->
<!--JS-->
<?php
$this->load->view("comun/js");
?>


<script>


  function getBlockchain() {

    var myAddressHeader = "cVS9zNomEDHBNYEsQ1JFMbE2ufHXRVwVsK";
    var myAddressBody = "cV2jmh71Cx6wvBPpH7WdB6oT2ErECSH6vd";


    $.ajax({
      url: 'https://explorer.cha.terahash.cl/api/addr/' + myAddressHeader,
      data: { a: ''},
      type: "GET",
      success: function(respuesta) {


        if(respuesta.transactions.length > 0) {


          var txElegidas = [];
          var flag = false;


          $.each(respuesta.transactions, function(index, tx) {

            $.ajax({
              url: 'https://explorer.cha.terahash.cl/api/tx/' + tx,
              data: { a: ''},
              type: "GET",

              success: function(respuesta) {

                $.each(respuesta.vout, function(index, outs) {

                  var OP_RETURN = outs.scriptPubKey.asm;

                  if(OP_RETURN !== undefined && OP_RETURN !== null) {
                    if(outs.scriptPubKey.asm.indexOf('RETURN') > 0) {
                      txElegidas.push(outs);
                    }
                  }
                });


                if(txElegidas.length > 0) {
                  outs = txElegidas[0];



                // 0-4 PREFIX
                // 4-16 (12) --> STRING HEADER
                // 16 - 24 (8) --> LONG RUT
                // 24 - 28 (4) --> CONTADOR SHORT
                // 28 - 2*(CONTADOR)(9) --> STRING RAZON


                if(!flag) {
                  flag = true;


                 var headerHex = outs.scriptPubKey.hex.substring(4, 16); // STRING
                 var rutHex = outs.scriptPubKey.hex.substring(16, 24); // LONG
                 var contadorRazon = unpackShort(outs.scriptPubKey.hex.substring(24, 28)); // SHORT
                 var razonHex = outs.scriptPubKey.hex.substring(28, 46); // STRING
                 var fechaConHex = outs.scriptPubKey.hex.substring(46, 54); // LONG
                 var fechaActHex = outs.scriptPubKey.hex.substring(54, 62); // LONG
                 var terminoHex = outs.scriptPubKey.hex.substring(62, 64); // BOOLEAN
                 var contadorRepNombre = unpackShort(outs.scriptPubKey.hex.substring(64, 68)); // SHORT
                 var repNombreHex = outs.scriptPubKey.hex.substring(68, 118); // STRING
                 var repRutHex = outs.scriptPubKey.hex.substring(118, 126); // LONG
                 var sociosHex = outs.scriptPubKey.hex.substring(126, 131); // SHORT

                 console.log("HEADER: " + hex2a(headerHex));
                 console.log("RUT: " + unpackLong(rutHex));
                 console.log("RAZON: " + hex2a(razonHex));
                 console.log("F. CONS: " + (unpackLong(fechaConHex)));
                 console.log("F. ACT: " + (unpackLong(fechaActHex)));
                 console.log("TERMINO: " + terminoHex);
                 console.log("REP NOMBRE: " + hex2a(repNombreHex));
                 console.log("REP RUT: " + unpackLong(repRutHex));
                 console.log("SOCIOS: " + unpackShort(sociosHex));



                 var contenidoEmpresa = "";
                 contenidoEmpresa += "<div>";
                 contenidoEmpresa += "<label class='col-lg-3'>Rut Empresa: </label>";
                 contenidoEmpresa += "<input class='col-lg-5' type='text' disabled value='" + unpackLong(rutHex) + "' />";
                 contenidoEmpresa += "</div>";
                 contenidoEmpresa += "<div>";
                 contenidoEmpresa += "<label class='col-lg-3'>Razón Social: </label>";
                 contenidoEmpresa += "<input class='col-lg-5' type='text' disabled value='" + hex2a(razonHex) + "' />";
                 contenidoEmpresa += "</div>";
                 contenidoEmpresa += "<div>";
                 contenidoEmpresa += "<label class='col-lg-3'>Fecha Constitucion: </label>";
                 contenidoEmpresa += "<input class='col-lg-5' type='text' disabled value='" +  moment.unix(unpackLong(fechaConHex)).format("DD/MM/YYYY") + "' />";
                 contenidoEmpresa += "</div>";
                 contenidoEmpresa += "<div>";
                 contenidoEmpresa += "<label class='col-lg-3'>Fecha Inicio Actividades: </label>";
                 contenidoEmpresa += "<input class='col-lg-5' type='text' disabled value='" + moment.unix(unpackLong(fechaActHex)).format("DD/MM/YYYY") + "' />";
                 contenidoEmpresa += "</div>";
                 contenidoEmpresa += "<div>";
                 contenidoEmpresa += "<label class='col-lg-3'>Cantidad de Socios: </label>";
                 contenidoEmpresa += "<input class='col-lg-5' type='text' disabled value='" + unpackShort(sociosHex) + "' />";
                 contenidoEmpresa += "</div>";



                 var contenidoRepresentante = "";
                 contenidoRepresentante += "<div>";
                 contenidoRepresentante += "<label class='col-lg-3'>Rut Representante: </label>";
                 contenidoRepresentante += "<input class='col-lg-5' type='text' disabled value='" + unpackLong(repRutHex) + "' />";
                 contenidoRepresentante += "</div>";
                 contenidoRepresentante += "<div>";
                 contenidoRepresentante += "<label class='col-lg-3'>Nombre Representante: </label>";
                 contenidoRepresentante += "<input class='col-lg-5' type='text' disabled value='" + hex2a(repNombreHex) + "' />";
                 contenidoRepresentante += "</div>";



                 $('#datosEmpresa').html(contenidoEmpresa);
                 $('#datosRepresentante_legal').html(contenidoRepresentante);
                 $('#datosSocios').html(contenidoSocios);



               }
             }




           },
           error: function() {
            console.log("No se ha podido obtener la información");
          }
        });
});


}  else {
  alert('No hay TXs');
}
},
error: function() {
  console.log("No se ha podido obtener la información");
}
});



}






function getData() {

  $.ajax({
    url: 'crear/get_datos',
    data: { a: ''},
    type: "POST",
    success: function(respuesta) {
      console.log(respuesta);


      var contenidoEmpresa = "";
      contenidoEmpresa += "<div class='row'>";
      contenidoEmpresa += "<h5>Rut : "+ respuesta.rut +"</h5>";
      contenidoEmpresa += "</div>";
      contenidoEmpresa += "<h5>Razon Social :" + respuesta.razon_social + "</h5>";
      contenidoEmpresa += "<h5>Fecha de Constitucion :" + moment.unix(respuesta.fecha_constitucion).format("DD/MM/YYYY") + "</h5>";
      contenidoEmpresa += "<h5>Fecha de Inicio de Actividades :" + moment.unix(respuesta.fecha_inicio_actividades).format("DD/MM/YYYY")  + "</h5>";
      var contenidoRepresentante_legal="";
      contenidoRepresentante_legal += "<input value='" + respuesta.rep_nombre + "'>";
      contenidoRepresentante_legal += "<input value='" + respuesta.rep_rut + "'></br>";
      var contenidoSocios = "";

      contenidoSocios += "<input value='" + respuesta.socios[0].nombre + "'>";
      contenidoSocios += "<input value='" + respuesta.socios[0].rut + "'>";
      contenidoSocios += "<input value='" + respuesta.socios[1].acciones + "'></br>";
      contenidoSocios += "<input value='" + respuesta.socios[1].nombre + "'>";
      contenidoSocios += "<input value='" + respuesta.socios[1].rut + "'>";
      contenidoSocios += "<input value='" + respuesta.socios[1].acciones + "'>";
      $.each(respuesta.socios, function(index, socio) {


        console.log(socio.nombre);
      });


      $('#datosEmpresa').html(contenidoEmpresa);
      $('#datosRepresentante_legal').html(contenidoRepresentante_legal);
      $('#datosSocios').html(contenidoSocios);



    },
    error: function() {
      console.log("No se ha podido obtener la información");
    }
  });

}


</script>

</body>
<?php
$this->load->view("comun/footer");
?>
</html>