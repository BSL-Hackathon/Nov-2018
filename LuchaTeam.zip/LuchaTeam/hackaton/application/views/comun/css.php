 <link rel="stylesheet" href="<?=base_url()?>assets/css/bootstrap.css">
 <link rel="stylesheet" href="<?=base_url()?>assets/css/bootstrap-grid.css">
 <link rel="stylesheet" href="<?=base_url()?>assets/css/bootstrap-reboot.css">
 <style>
 	.sombra{
 		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
 	}
 </style>