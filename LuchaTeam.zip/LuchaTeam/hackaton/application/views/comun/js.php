<script src="<?=base_url()?>assets/js/bootstrap.bundle.js"></script>
<script src="<?=base_url()?>assets/js/bootstrap.js"></script>
<script src="<?=base_url()?>assets/js/jquery-3.3.1.min.js"></script>
<script src="<?=base_url()?>assets/js/moment.js"></script>
<script src="<?=base_url()?>assets/js/req.js"></script>