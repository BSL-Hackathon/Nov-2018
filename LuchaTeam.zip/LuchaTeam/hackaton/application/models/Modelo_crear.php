
<?php
	class Modelo_crear extends CI_Model {
public function registros(){
    		return "true";
    	}
}